# Smart Watch V1 — Seven-Screen Firmware

ESP-IDF firmware for the Smart Watch V1 prototype based on the **ESP32-S3-Touch-AMOLED-2.06** board.

## Hardware and software baseline

- MCU target: ESP32-S3 (`CONFIG_IDF_TARGET=esp32s3`)
- Display: 480 × 480 AMOLED touch display
- UI framework: LVGL 9.x
- Board support: Waveshare ESP32-S3 Touch AMOLED 2.06 BSP
- Build system: ESP-IDF / CMake
- Dependency lock: ESP-IDF 5.5.3 (see `dependencies.lock`); component manifests declare ESP-IDF >= 5.3.2

The project uses the board's QMI8658 accelerometer/gyroscope, PCF85063 RTC, microSD interface and audio codec.

## UI screens

The screen registry in `main/main.c` registers seven screens:

1. Home
2. Clock
3. IMU — live accelerometer and gyroscope readings
4. Recorder — WAV audio recording
5. Player — browse and play audio files from the SD card
6. IMU Logger — log motion sensor readings to CSV at 100 Hz
7. Classify — on-device sitting/walking activity classification

## Data and storage

- Audio recordings are written under `/sdcard/rec/`.
- IMU log files are written under `/sdcard/imu/`.
- The recorder and IMU logger maintain file counters in NVS.
- The activity classifier uses 50-sample windows at 100 Hz and an 84-element feature vector. The model source is in `main/model_classifier.h`.

## Build

Install ESP-IDF 5.5.3 (or a compatible release satisfying the component manifests), activate the ESP-IDF environment, then run from this directory:

```bash
idf.py set-target esp32s3
idf.py build
idf.py -p <PORT> flash monitor
```

ESP-IDF Component Manager resolves dependencies from `main/idf_component.yml`, `components/bsp_extra/idf_component.yml` and `dependencies.lock`. The generated `managed_components/` and `build/` directories are intentionally not tracked; they are recreated by the build process.

## Project contents

- `main/` — application entry point, screen implementations, UI theme, IMU feature extraction and classifier model
- `components/bsp_extra/` — board-specific helper component
- `partitions.csv` — custom partition table
- `sdkconfig.defaults` — ESP32-S3 and LVGL configuration defaults
- `dependencies.lock` — resolved component versions

## Import note

This repository copy preserves the uploaded source and configuration files. The original project naming strings (including `project(smartwatch_5screen)` in the root CMake file) have not been changed. Firmware compilation and hardware operation have not been independently verified as part of this upload.
