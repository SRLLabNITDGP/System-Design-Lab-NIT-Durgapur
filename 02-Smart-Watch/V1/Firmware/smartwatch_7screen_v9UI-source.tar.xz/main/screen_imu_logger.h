/*
 * ================================================================
 *  screen_imu_logger.h — Screen 5: IMU Data Logger
 *
 *  Records ACC + GYR at exactly 100 Hz (one row per 10 ms) to a
 *  CSV file on the SD card in the format:
 *    Time(ms),ACC_X,ACC_Y,ACC_Z,GYR_X,GYR_Y,GYR_Z,Label
 *
 *  Four buttons:
 *    [1] START/STOP   — begins or ends the recording session
 *    [2] Walking      — sets label to "walking"
 *    [3] Running      — sets label to "running"
 *    [4] Sitting      — sets label to "sitting"
 *
 *  Rules:
 *  - Button 1 must be pressed first; buttons 2/3/4 ignored otherwise.
 *  - While recording, whichever label button is active turns RED.
 *    All others stay their default colour.
 *  - Default label (after pressing START before any label btn) = "idle".
 *  - Navigating away from this screen stops recording immediately and
 *    shows a message.
 *  - File counter persisted in NVS (same pattern as audio recorder).
 *    Filename: imuN_NNNN.csv  (8.3 FAT safe).
 *
 *  Sampling:
 *  - Uses a FreeRTOS task + esp_timer ISR counter for 100 Hz:
 *    The esp_timer fires every 10 ms, increments an atomic counter,
 *    and the task reads the sensor and writes one CSV row per fire.
 *    This achieves exactly 100 rows/second without vTaskDelay drift.
 *
 *  Shares g_imu_dev / g_imu_ready from screen_imu.h (same I2C device,
 *  never re-added to the bus).
 * ================================================================
 */
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <stdatomic.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_err.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "driver/i2c_master.h"
#include "lvgl.h"
#include "bsp/esp-bsp.h"
#include "theme.h"

/* Shared IMU device from screen_imu.h */
extern i2c_master_dev_handle_t g_imu_dev;
extern bool                    g_imu_ready;

/* Shared screen-manager active index from main.c */
extern screen_manager_t g_sm;

#define IML_TAG          "IMU_Logger"
#define IML_DIR          "/sdcard/imu"
#define IML_NVS_NS       "imu_log"
#define IML_NVS_KEY      "file_ctr"

/* IMU register addresses */
#define IML_REG_AX_L     0x35
#define IML_REG_GX_L     0x3B
#define IML_ACC_SCALE    (4.0f   / 32768.0f)
#define IML_GYR_SCALE    (512.0f / 32768.0f)

/* This screen's index in the tileview (registered as 6th = index 5) */
#define IML_SCREEN_IDX   5

/* ── State ───────────────────────────────────────────────── */
typedef enum {
    IML_IDLE = 0,
    IML_RECORDING
} iml_state_t;

static volatile iml_state_t _iml_state       = IML_IDLE;
static volatile bool        _iml_req_stop    = false;
static int                  _iml_file_ctr    = -1;   /* -1 = not yet loaded */

/* Current label string — written into every CSV row */
static char  _iml_label[16] = "idle";

/* Timer tick counter — incremented by esp_timer ISR at 100 Hz */
static volatile atomic_int _iml_tick = 0;

/* ── Widget handles ──────────────────────────────────────── */
static lv_obj_t *_iml_btn_start  = NULL;
static lv_obj_t *_iml_lbl_start  = NULL;
static lv_obj_t *_iml_btn_walk   = NULL;
static lv_obj_t *_iml_btn_run    = NULL;
static lv_obj_t *_iml_btn_sit    = NULL;
static lv_obj_t *_iml_status_lbl = NULL;
static lv_obj_t *_iml_rows_lbl   = NULL;   /* live row count */

/* esp_timer handle */
static esp_timer_handle_t _iml_timer = NULL;

/* ── NVS helpers ─────────────────────────────────────────── */
static int _iml_load_counter(void)
{
    nvs_handle_t h;
    int32_t val = 0;
    if (nvs_open(IML_NVS_NS, NVS_READONLY, &h) == ESP_OK) {
        nvs_get_i32(h, IML_NVS_KEY, &val);
        nvs_close(h);
    }
    ESP_LOGI(IML_TAG, "Loaded IMU file counter: %d", (int)val);
    return (int)val;
}

static void _iml_save_counter(int val)
{
    nvs_handle_t h;
    if (nvs_open(IML_NVS_NS, NVS_READWRITE, &h) == ESP_OK) {
        nvs_set_i32(h, IML_NVS_KEY, (int32_t)val);
        nvs_commit(h);
        nvs_close(h);
    }
    ESP_LOGI(IML_TAG, "Saved IMU file counter: %d", val);
}

/* ── IMU read helper (uses shared g_imu_dev) ─────────────── */
static void _iml_read6(uint8_t reg, float scale,
                        float *x, float *y, float *z)
{
    uint8_t raw[6] = {0};
    if (i2c_master_transmit_receive(g_imu_dev, &reg, 1,
                                    raw, 6, pdMS_TO_TICKS(5)) != ESP_OK) {
        *x = *y = *z = 0.0f;
        return;
    }
    *x = (int16_t)((raw[1] << 8) | raw[0]) * scale;
    *y = (int16_t)((raw[3] << 8) | raw[2]) * scale;
    *z = (int16_t)((raw[5] << 8) | raw[4]) * scale;
}

/* ── 100 Hz esp_timer callback — just increments tick counter ─
 *    Runs in ISR context — do nothing except atomic increment.
 * ─────────────────────────────────────────────────────────── */
static void _iml_timer_cb(void *arg)
{
    atomic_fetch_add(&_iml_tick, 1);
}

/* ── Highlight active label button ──────────────────────── */
static void _iml_highlight_label(lv_obj_t *active_btn)
{
    /* Called from LVGL task — safe to touch widgets directly */
    lv_obj_t *btns[3] = { _iml_btn_walk, _iml_btn_run, _iml_btn_sit };
    for (int i = 0; i < 3; i++) {
        if (!btns[i]) continue;
        bool is_active = (btns[i] == active_btn);
        lv_obj_set_style_bg_color(btns[i],
            is_active ? lv_color_hex(C_RED_BTN)
                      : lv_color_hex(C_BLUE_BTN),
            LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

/* ── Logging task — runs on Core 1 ──────────────────────── */
static void _iml_log_task(void *pv)
{
    if (_iml_file_ctr < 0)
        _iml_file_ctr = _iml_load_counter();

    /* Filename: imuN_NNNN.csv — 9 chars name, 3 ext, FAT 8.3 safe
       "imuN_" = 5 chars, "0000" = 4 chars → "imuN_0000" = 9 chars
       But 8.3 only allows 8! Use "im_NNNN" = 7 chars — safe */
    char path[64];
    snprintf(path, sizeof(path), "%s/im_%04d.csv", IML_DIR, _iml_file_ctr);

    FILE *fp = fopen(path, "w");
    if (!fp) {
        ESP_LOGE(IML_TAG, "Cannot create %s", path);
        if (bsp_display_lock(pdMS_TO_TICKS(100))) {
            if (_iml_status_lbl && lv_obj_is_valid(_iml_status_lbl))
                lv_label_set_text(_iml_status_lbl, "ERROR: cannot create file");
            bsp_display_unlock();
        }
        _iml_state = IML_IDLE;
        vTaskDelete(NULL);
        return;
    }

    /* Increment and persist counter after successful open */
    _iml_file_ctr++;
    _iml_save_counter(_iml_file_ctr);

    /* Write CSV header */
    fprintf(fp, "Time(ms),ACC_X,ACC_Y,ACC_Z,GYR_X,GYR_Y,GYR_Z,Label\n");

    /* Start 100 Hz timer */
    atomic_store(&_iml_tick, 0);
    esp_timer_start_periodic(_iml_timer, 10000); /* 10 000 µs = 10 ms */

    uint32_t row_count  = 0;
    int      last_tick  = 0;
    int      elapsed_ms = 0;

    while (!_iml_req_stop) {
        /* Wait for next timer tick */
        int cur = atomic_load(&_iml_tick);
        if (cur == last_tick) {
            /* No new tick yet — yield briefly */
            vTaskDelay(1);
            continue;
        }
        /* Handle any missed ticks (write one row per tick) */
        while (last_tick != cur && !_iml_req_stop) {
            last_tick++;
            elapsed_ms += 10;

            float ax, ay, az, gx, gy, gz;
            _iml_read6(IML_REG_AX_L, IML_ACC_SCALE, &ax, &ay, &az);
            _iml_read6(IML_REG_GX_L, IML_GYR_SCALE, &gx, &gy, &gz);

            fprintf(fp, "%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%s\n",
                    elapsed_ms, ax, ay, az, gx, gy, gz, _iml_label);
            row_count++;
        }

        /* Update display every 100 rows (≈1 s) */
        if (row_count % 100 == 0) {
            if (bsp_display_lock(0)) {
                if (_iml_rows_lbl && lv_obj_is_valid(_iml_rows_lbl))
                    lv_label_set_text_fmt(_iml_rows_lbl,
                        "%lu rows  |  %s", (unsigned long)row_count, _iml_label);
                bsp_display_unlock();
            }
        }

        /* Auto-stop if user navigated away from this screen */
        if (g_sm.active_idx != IML_SCREEN_IDX) {
            _iml_req_stop = true;
            /* Show stopped message — we're off-screen but it's safe */
            ESP_LOGW(IML_TAG, "Screen left — recording stopped");
        }
    }

    /* Stop timer */
    esp_timer_stop(_iml_timer);

    fflush(fp);
    fclose(fp);

    const char *fname = strrchr(path, '/');
    fname = fname ? fname + 1 : path;

    ESP_LOGI(IML_TAG, "Saved %s  (%lu rows)", path, (unsigned long)row_count);

    /* Update UI — only if still on this screen */
    if (bsp_display_lock(pdMS_TO_TICKS(200))) {
        if (_iml_btn_start && lv_obj_is_valid(_iml_btn_start)) {
            lv_obj_set_style_bg_color(_iml_btn_start,
                lv_color_hex(C_GREEN_BTN),
                LV_PART_MAIN | LV_STATE_DEFAULT);
            lv_label_set_text(_iml_lbl_start, LV_SYMBOL_PLAY "  START");
        }
        if (_iml_status_lbl && lv_obj_is_valid(_iml_status_lbl)) {
            lv_label_set_text_fmt(_iml_status_lbl,
                "Saved: %s  (%lu rows)", fname, (unsigned long)row_count);
            lv_obj_set_style_text_color(_iml_status_lbl,
                lv_color_hex(C_TEXT_GREEN), 0);
        }
        if (_iml_rows_lbl && lv_obj_is_valid(_iml_rows_lbl))
            lv_label_set_text(_iml_rows_lbl, "");
        /* Reset label buttons to default colour */
        _iml_highlight_label(NULL);
        bsp_display_unlock();
    }

    _iml_req_stop = false;
    _iml_state    = IML_IDLE;
    strncpy(_iml_label, "idle", sizeof(_iml_label));
    vTaskDelete(NULL);
}

/* ── Button callbacks ────────────────────────────────────── */
static void _iml_start_cb(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;

    if (_iml_state == IML_IDLE) {
        /* Start recording */
        _iml_req_stop = false;
        _iml_state    = IML_RECORDING;
        strncpy(_iml_label, "idle", sizeof(_iml_label));

        lv_obj_set_style_bg_color(_iml_btn_start,
            lv_color_hex(C_RED_BTN),
            LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_label_set_text(_iml_lbl_start, LV_SYMBOL_STOP "  STOP");
        lv_label_set_text(_iml_status_lbl, "Recording...  Label: idle");
        lv_obj_set_style_text_color(_iml_status_lbl,
            lv_color_hex(0xFF8888), 0);
        lv_label_set_text(_iml_rows_lbl, "0 rows  |  idle");

        xTaskCreatePinnedToCore(_iml_log_task, "iml_task",
                                6 * 1024, NULL, 6, NULL, 1);
    } else {
        /* Stop recording */
        _iml_req_stop = true;
        lv_label_set_text(_iml_status_lbl, "Saving...");
        lv_obj_set_style_text_color(_iml_status_lbl,
            lv_color_hex(0xFFDD55), 0);
    }
}

static void _iml_label_cb(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    /* Ignore if not recording */
    if (_iml_state != IML_RECORDING) return;

    const char *lbl = (const char *)lv_event_get_user_data(e);
    if (!lbl) return;

    strncpy(_iml_label, lbl, sizeof(_iml_label) - 1);

    /* Highlight this button red, others back to blue */
    lv_obj_t *sender = (lv_obj_t *)lv_event_get_target(e);
    _iml_highlight_label(sender);

    /* Update status */
    char msg[48];
    snprintf(msg, sizeof(msg), "Recording...  Label: %s", lbl);
    lv_label_set_text(_iml_status_lbl, msg);
    lv_obj_set_style_text_color(_iml_status_lbl,
        lv_color_hex(0xFF8888), 0);
}

/* ── Screen create / update ──────────────────────────────── */
lv_obj_t *screen_imu_logger_create(lv_obj_t *tile)
{
    /* Create /sdcard/imu directory if needed */
    struct stat st = {0};
    if (stat(IML_DIR, &st) != 0) mkdir(IML_DIR, 0775);

    /* Create the 100 Hz esp_timer (not started yet) */
    if (!_iml_timer) {
        esp_timer_create_args_t ta = {
            .callback        = _iml_timer_cb,
            .arg             = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name            = "iml_100hz",
        };
        esp_timer_create(&ta, &_iml_timer);
    }

    /* ── Tile background ── */
    lv_obj_set_style_bg_color(tile, lv_color_hex(C_BG_MID), 0);
    lv_obj_set_style_bg_opa(tile, LV_OPA_COVER, 0);
    lv_obj_clear_flag(tile, LV_OBJ_FLAG_SCROLLABLE);

    /* ── Title ── */
    lv_obj_t *title = lv_label_create(tile);
    lv_label_set_text(title, "IMU Logger");
    lv_obj_set_style_text_font(title, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(title, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 22);

    lv_obj_t *acc_line = lv_obj_create(tile);
    lv_obj_set_size(acc_line, 160, 3);
    lv_obj_align(acc_line, LV_ALIGN_TOP_MID, 0, 58);
    lv_obj_set_style_bg_color(acc_line, lv_color_hex(C_ACCENT), 0);
    lv_obj_set_style_border_width(acc_line, 0, 0);
    lv_obj_set_style_radius(acc_line, 2, 0);
    lv_obj_clear_flag(acc_line, LV_OBJ_FLAG_SCROLLABLE);

    /*
     * Layout (480×480):
     *  Row 1  y≈75:   [START/STOP]  — full width centred
     *  Row 2  y≈165:  [Walking] [Running]
     *  Row 3  y≈255:  [Sitting]
     *  Row 4  y≈345:  status label
     *  Row 5  y≈400:  row count label
     *
     * All buttons are BTN_W_FULL wide (220px), height 72px.
     * Walking & Running are side-by-side, each 105px wide with 10px gap.
     * All sit inside the centre safe zone (120–360 px).
     */

    /* ── Button 1: START / STOP ── */
    _iml_btn_start = lv_btn_create(tile);
    lv_obj_set_size(_iml_btn_start, BTN_W_FULL, BTN_H);
    lv_obj_align(_iml_btn_start, LV_ALIGN_TOP_MID, 0, 75);
    lv_obj_set_style_radius(_iml_btn_start, BTN_H / 2, LV_PART_MAIN);
    lv_obj_set_style_bg_color(_iml_btn_start, lv_color_hex(C_GREEN_BTN),
                              LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(_iml_btn_start, lv_color_hex(C_GREEN_BTN_PR),
                              LV_PART_MAIN | LV_STATE_PRESSED);
    lv_obj_set_style_shadow_width(_iml_btn_start, 16, LV_PART_MAIN);
    lv_obj_set_style_shadow_color(_iml_btn_start,
        lv_color_hex(C_GREEN_BTN), LV_PART_MAIN);
    lv_obj_add_event_cb(_iml_btn_start, _iml_start_cb, LV_EVENT_CLICKED, NULL);

    _iml_lbl_start = lv_label_create(_iml_btn_start);
    lv_label_set_text(_iml_lbl_start, LV_SYMBOL_PLAY "  START");
    lv_obj_set_style_text_font(_iml_lbl_start, &lv_font_montserrat_20, 0);
    lv_obj_set_style_text_color(_iml_lbl_start, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_center(_iml_lbl_start);

    /* ── Button 2: Walking  (left of pair) ── */
    _iml_btn_walk = lv_btn_create(tile);
    lv_obj_set_size(_iml_btn_walk, 102, BTN_H);
    lv_obj_align(_iml_btn_walk, LV_ALIGN_TOP_MID, -56, 165);
    lv_obj_set_style_radius(_iml_btn_walk, 10, LV_PART_MAIN);
    lv_obj_set_style_bg_color(_iml_btn_walk, lv_color_hex(C_BLUE_BTN),
                              LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(_iml_btn_walk, lv_color_hex(C_BLUE_BTN_PR),
                              LV_PART_MAIN | LV_STATE_PRESSED);
    lv_obj_add_event_cb(_iml_btn_walk, _iml_label_cb,
                        LV_EVENT_CLICKED, (void *)"walking");

    lv_obj_t *lbl_w = lv_label_create(_iml_btn_walk);
    lv_label_set_text(lbl_w, LV_SYMBOL_PLAY "\nWalking");
    lv_obj_set_style_text_font(lbl_w, &lv_font_montserrat_16, 0);
    lv_obj_set_style_text_color(lbl_w, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_set_style_text_align(lbl_w, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_center(lbl_w);

    /* ── Button 3: Running  (right of pair) ── */
    _iml_btn_run = lv_btn_create(tile);
    lv_obj_set_size(_iml_btn_run, 102, BTN_H);
    lv_obj_align(_iml_btn_run, LV_ALIGN_TOP_MID, 56, 165);
    lv_obj_set_style_radius(_iml_btn_run, 10, LV_PART_MAIN);
    lv_obj_set_style_bg_color(_iml_btn_run, lv_color_hex(C_BLUE_BTN),
                              LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(_iml_btn_run, lv_color_hex(C_BLUE_BTN_PR),
                              LV_PART_MAIN | LV_STATE_PRESSED);
    lv_obj_add_event_cb(_iml_btn_run, _iml_label_cb,
                        LV_EVENT_CLICKED, (void *)"running");

    lv_obj_t *lbl_r = lv_label_create(_iml_btn_run);
    lv_label_set_text(lbl_r, LV_SYMBOL_LOOP "\nRunning");
    lv_obj_set_style_text_font(lbl_r, &lv_font_montserrat_16, 0);
    lv_obj_set_style_text_color(lbl_r, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_set_style_text_align(lbl_r, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_center(lbl_r);

    /* ── Button 4: Sitting  (centred, below pair) ── */
    _iml_btn_sit = lv_btn_create(tile);
    lv_obj_set_size(_iml_btn_sit, BTN_W_FULL, BTN_H);
    lv_obj_align(_iml_btn_sit, LV_ALIGN_TOP_MID, 0, 255);
    lv_obj_set_style_radius(_iml_btn_sit, 10, LV_PART_MAIN);
    lv_obj_set_style_bg_color(_iml_btn_sit, lv_color_hex(C_BLUE_BTN),
                              LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(_iml_btn_sit, lv_color_hex(C_BLUE_BTN_PR),
                              LV_PART_MAIN | LV_STATE_PRESSED);
    lv_obj_add_event_cb(_iml_btn_sit, _iml_label_cb,
                        LV_EVENT_CLICKED, (void *)"sitting");

    lv_obj_t *lbl_s = lv_label_create(_iml_btn_sit);
    lv_label_set_text(lbl_s, LV_SYMBOL_PAUSE "\nSitting");
    lv_obj_set_style_text_font(lbl_s, &lv_font_montserrat_16, 0);
    lv_obj_set_style_text_color(lbl_s, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_set_style_text_align(lbl_s, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_center(lbl_s);

    /* ── Status label ── */
    _iml_status_lbl = lv_label_create(tile);
    lv_label_set_long_mode(_iml_status_lbl, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(_iml_status_lbl, DISP_W - 80);
    lv_label_set_text(_iml_status_lbl, "Press START to begin logging");
    lv_obj_set_style_text_font(_iml_status_lbl, &lv_font_montserrat_14, 0);
    lv_obj_set_style_text_color(_iml_status_lbl, lv_color_hex(C_TEXT_DIM), 0);
    lv_obj_set_style_text_align(_iml_status_lbl, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(_iml_status_lbl, LV_ALIGN_BOTTOM_MID, 0, -50);

    /* ── Row counter label ── */
    _iml_rows_lbl = lv_label_create(tile);
    lv_label_set_text(_iml_rows_lbl, "");
    lv_obj_set_style_text_font(_iml_rows_lbl, &lv_font_montserrat_14, 0);
    lv_obj_set_style_text_color(_iml_rows_lbl, lv_color_hex(C_ACCENT), 0);
    lv_obj_set_style_text_align(_iml_rows_lbl, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(_iml_rows_lbl, LV_ALIGN_BOTTOM_MID, 0, -24);

    return tile;
}

void screen_imu_logger_update(lv_obj_t *tile)
{
    (void)tile;
    /* All updates driven by the logging task + button callbacks */
}
