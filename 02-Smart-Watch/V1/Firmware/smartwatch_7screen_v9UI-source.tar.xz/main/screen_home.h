/*
 * ================================================================
 *  screen_home.h — Screen 0: Home
 *  Matches the Arduino smartwatch home screen theme.
 * ================================================================
 */
#pragma once
#include "lvgl.h"
#include "theme.h"

lv_obj_t *screen_home_create(lv_obj_t *tile)
{
    /* Background gradient (dark navy → deep blue) */
    static lv_style_t s_bg;
    lv_style_init(&s_bg);
    lv_style_set_bg_color(&s_bg, lv_color_hex(0x0A0A1A));
    lv_style_set_bg_grad_color(&s_bg, lv_color_hex(0x0D1B4B));
    lv_style_set_bg_grad_dir(&s_bg, LV_GRAD_DIR_VER);
    lv_style_set_bg_opa(&s_bg, LV_OPA_COVER);
    lv_obj_add_style(tile, &s_bg, 0);
    lv_obj_clear_flag(tile, LV_OBJ_FLAG_SCROLLABLE);

    /* Accent bar — top-centre */
    lv_obj_t *accent = lv_obj_create(tile);
    lv_obj_set_size(accent, 80, 4);
    lv_obj_align(accent, LV_ALIGN_TOP_MID, 0, 60);
    lv_obj_set_style_bg_color(accent, lv_color_hex(C_ACCENT), 0);
    lv_obj_set_style_radius(accent, 2, 0);
    lv_obj_set_style_border_width(accent, 0, 0);
    lv_obj_clear_flag(accent, LV_OBJ_FLAG_SCROLLABLE);

    /* "Hello," */
    lv_obj_t *lbl_hi = lv_label_create(tile);
    lv_label_set_text(lbl_hi, "Hello,");
    lv_obj_set_style_text_color(lbl_hi, lv_color_hex(C_TEXT_SUB), 0);
    lv_obj_set_style_text_font(lbl_hi, &lv_font_montserrat_20, 0);
    lv_obj_align(lbl_hi, LV_ALIGN_TOP_MID, 0, 85);

    /* Name — centred */
    lv_obj_t *lbl_name = lv_label_create(tile);
    lv_label_set_text(lbl_name, "NIT Durgapur");
    lv_obj_set_style_text_color(lbl_name, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_set_style_text_font(lbl_name, &lv_font_montserrat_36, 0);
    lv_obj_align(lbl_name, LV_ALIGN_CENTER, 0, -50);

    /* Divider */
    lv_obj_t *div = lv_obj_create(tile);
    lv_obj_set_size(div, 220, 2);
    lv_obj_align(div, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(div, lv_color_hex(C_DIVIDER), 0);
    lv_obj_set_style_border_width(div, 0, 0);
    lv_obj_clear_flag(div, LV_OBJ_FLAG_SCROLLABLE);

    /* Subtitle */
    lv_obj_t *lbl_sub = lv_label_create(tile);
    lv_label_set_text(lbl_sub, "ESP32-S3 Smartwatch");
    lv_obj_set_style_text_color(lbl_sub, lv_color_hex(C_TEXT_DIM), 0);
    lv_obj_set_style_text_font(lbl_sub, &lv_font_montserrat_14, 0);
    lv_obj_align(lbl_sub, LV_ALIGN_CENTER, 0, 35);

    /* Hint */
    lv_obj_t *lbl_hint = lv_label_create(tile);
    lv_label_set_text(lbl_hint, LV_SYMBOL_RIGHT " Tap sides to navigate");
    lv_obj_set_style_text_color(lbl_hint, lv_color_hex(C_TEXT_FAINT), 0);
    lv_obj_set_style_text_font(lbl_hint, &lv_font_montserrat_12, 0);
    lv_obj_align(lbl_hint, LV_ALIGN_BOTTOM_MID, 0, -50);

    /* 6-dot page indicator */
    for (int i = 0; i < 7; i++) {
        lv_obj_t *dot = lv_obj_create(tile);
        lv_obj_set_size(dot, (i == 0) ? 20 : 8, 8);
        lv_obj_align(dot, LV_ALIGN_BOTTOM_MID, -66 + i * 22, -26);
        lv_obj_set_style_radius(dot, 4, 0);
        lv_obj_set_style_bg_color(dot,
            (i == 0) ? lv_color_hex(C_ACCENT) : lv_color_hex(0x263238), 0);
        lv_obj_set_style_border_width(dot, 0, 0);
        lv_obj_clear_flag(dot, LV_OBJ_FLAG_SCROLLABLE);
    }

    return tile;
}

void screen_home_update(lv_obj_t *tile)
{
    (void)tile;
}
