/*
 * ================================================================
 *  screen_recorder.h — Screen 3: Audio Recorder
 *
 *  FIX 3: Timer resets to 00:00:00 when STOP pressed
 *  FIX 4: Counter persisted in NVS — survives power-off,
 *          never overwrites. Filename stays rec_NNNN.wav
 *          (8.3 FAT format — works WITHOUT LFN enabled)
 *  FIX 6: Blocks recording if playback is active (g_audio_busy)
 * ================================================================
 */
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_err.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "lvgl.h"
#include "bsp/esp-bsp.h"
#include "bsp_board_extra.h"
#include "theme.h"

/* FIX 6: shared audio state from main.c */
extern volatile int g_audio_busy;

#define REC_TAG            "Screen_Rec"
#define REC_DIR            "/sdcard/rec"
#define REC_SAMPLE_RATE    16000
#define REC_CHANNELS       2
#define REC_BITS           16
#define REC_BUF_SAMPLES    1024
#define REC_BUF_BYTES      (REC_BUF_SAMPLES * REC_CHANNELS * (REC_BITS / 8))

/* NVS namespace and key for the persistent counter */
#define REC_NVS_NAMESPACE  "recorder"
#define REC_NVS_KEY        "file_ctr"

/* WAV header */
typedef struct {
    char     riff_id[4];   uint32_t riff_size;
    char     wave_id[4];   char     fmt_id[4];
    uint32_t fmt_size;     uint16_t audio_format;
    uint16_t num_channels; uint32_t sample_rate;
    uint32_t byte_rate;    uint16_t block_align;
    uint16_t bits;         char     data_id[4];
    uint32_t data_size;
} __attribute__((packed)) rec_wav_hdr_t;

static void _rec_fill_wav(rec_wav_hdr_t *h, uint32_t db,
                           uint32_t rate, uint16_t ch, uint16_t bits)
{
    memcpy(h->riff_id,  "RIFF", 4);
    h->riff_size      = db + sizeof(rec_wav_hdr_t) - 8;
    memcpy(h->wave_id, "WAVE", 4);
    memcpy(h->fmt_id,  "fmt ", 4);
    h->fmt_size       = 16;
    h->audio_format   = 1;
    h->num_channels   = ch;
    h->sample_rate    = rate;
    h->bits           = bits;
    h->block_align    = ch * (bits / 8);
    h->byte_rate      = rate * h->block_align;
    memcpy(h->data_id, "data", 4);
    h->data_size      = db;
}

/* ── FIX 4: NVS counter helpers ──────────────────────────
 *  _rec_load_counter()  — reads last saved value from NVS.
 *                         Returns 0 if NVS has no entry yet.
 *  _rec_save_counter()  — writes updated value to NVS so it
 *                         survives the next power cycle.
 * ─────────────────────────────────────────────────────── */
static int _rec_load_counter(void)
{
    nvs_handle_t h;
    int32_t val = 0;
    if (nvs_open(REC_NVS_NAMESPACE, NVS_READONLY, &h) == ESP_OK) {
        nvs_get_i32(h, REC_NVS_KEY, &val);   /* silently ignores NOT_FOUND */
        nvs_close(h);
    }
    ESP_LOGI(REC_TAG, "Loaded file counter from NVS: %d", (int)val);
    return (int)val;
}

static void _rec_save_counter(int val)
{
    nvs_handle_t h;
    if (nvs_open(REC_NVS_NAMESPACE, NVS_READWRITE, &h) == ESP_OK) {
        nvs_set_i32(h, REC_NVS_KEY, (int32_t)val);
        nvs_commit(h);
        nvs_close(h);
    }
    ESP_LOGI(REC_TAG, "Saved file counter to NVS: %d", val);
}

/* State */
typedef enum { REC_IDLE = 0, REC_RECORDING } rec_st_t;
static volatile rec_st_t  _rec_state    = REC_IDLE;
static volatile bool      _rec_req_stop = false;
/* Counter loaded from NVS once on first use */
static int                _rec_file_ctr = -1;   /* -1 = not yet loaded */

/* Widget handles */
static lv_obj_t *_rec_btn     = NULL;
static lv_obj_t *_rec_btn_lbl = NULL;
static lv_obj_t *_rec_timer   = NULL;
static lv_obj_t *_rec_status  = NULL;

/* Recording task */
static void _rec_task(void *pv)
{
    /* FIX 4: load counter from NVS on first recording after boot */
    if (_rec_file_ctr < 0) {
        _rec_file_ctr = _rec_load_counter();
    }

    /* Filename: rec_NNNN.wav  — 8-char name, fits FAT 8.3 without LFN */
    char path[64];
    snprintf(path, sizeof(path), "%s/rec_%04d.wav", REC_DIR, _rec_file_ctr);

    FILE *fp = fopen(path, "wb");
    if (!fp) {
        ESP_LOGE(REC_TAG, "Cannot create %s", path);
        if (bsp_display_lock(pdMS_TO_TICKS(100))) {
            lv_label_set_text(_rec_status, "ERROR: cannot create file");
            lv_obj_set_style_text_color(_rec_status, lv_color_hex(0xFF4444), 0);
            bsp_display_unlock();
        }
        g_audio_busy  = 0;
        _rec_state    = REC_IDLE;
        vTaskDelete(NULL);
        return;
    }

    /* FIX 4: increment and persist counter AFTER successful open */
    _rec_file_ctr++;
    _rec_save_counter(_rec_file_ctr);

    rec_wav_hdr_t hdr;
    _rec_fill_wav(&hdr, 0, REC_SAMPLE_RATE, REC_CHANNELS, REC_BITS);
    fwrite(&hdr, 1, sizeof(hdr), fp);

    int16_t *buf = (int16_t *)malloc(REC_BUF_BYTES);
    if (!buf) {
        fclose(fp);
        g_audio_busy = 0;
        _rec_state   = REC_IDLE;
        vTaskDelete(NULL);
        return;
    }

    uint32_t total = 0;
    int64_t  t0    = esp_timer_get_time();

    while (!_rec_req_stop) {
        size_t rd = 0;
        if (bsp_extra_i2s_read(buf, REC_BUF_BYTES, &rd,
                                pdMS_TO_TICKS(200)) != ESP_OK || rd == 0) {
            vTaskDelay(pdMS_TO_TICKS(5));
            continue;
        }
        fwrite(buf, 1, rd, fp);
        total += (uint32_t)rd;

        int sec = (int)((esp_timer_get_time() - t0) / 1000000LL);
        if (bsp_display_lock(0)) {
            lv_label_set_text_fmt(_rec_timer, "%02d:%02d:%02d",
                                  sec / 3600, (sec % 3600) / 60, sec % 60);
            bsp_display_unlock();
        }
    }

    /* Finalise WAV header */
    rewind(fp);
    _rec_fill_wav(&hdr, total, REC_SAMPLE_RATE, REC_CHANNELS, REC_BITS);
    fwrite(&hdr, 1, sizeof(hdr), fp);
    fclose(fp);
    free(buf);

    const char *fname = strrchr(path, '/');
    fname = fname ? fname + 1 : path;

    if (bsp_display_lock(pdMS_TO_TICKS(200))) {
        lv_obj_set_style_bg_color(_rec_btn, lv_color_hex(C_GREEN_BTN),
                                  LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_label_set_text(_rec_btn_lbl, LV_SYMBOL_AUDIO "  REC");
        /* FIX 3: reset timer to zero after saving */
        lv_label_set_text(_rec_timer, "00:00:00");
        lv_label_set_text_fmt(_rec_status, "Saved: %s  (%lu kB)",
                              fname, (unsigned long)((total + sizeof(hdr)) / 1024));
        lv_obj_set_style_text_color(_rec_status, lv_color_hex(C_TEXT_GREEN), 0);
        bsp_display_unlock();
    }

    _rec_req_stop = false;
    _rec_state    = REC_IDLE;
    g_audio_busy  = 0;
    vTaskDelete(NULL);
}

/* Button callback */
static void _rec_btn_cb(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;

    if (_rec_state == REC_IDLE) {
        /* FIX 6: block if playback is active */
        if (g_audio_busy == 2) {
            lv_label_set_text(_rec_status,
                "Unable to record:\naudio is playing");
            lv_obj_set_style_text_color(_rec_status,
                lv_color_hex(0xFF8844), 0);
            return;
        }

        g_audio_busy  = 1;
        _rec_req_stop = false;
        _rec_state    = REC_RECORDING;

        lv_obj_set_style_bg_color(_rec_btn, lv_color_hex(C_RED_BTN),
                                  LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_label_set_text(_rec_btn_lbl, LV_SYMBOL_STOP "  STOP");
        lv_label_set_text(_rec_timer, "00:00:00");
        lv_label_set_text(_rec_status, "Recording...");
        lv_obj_set_style_text_color(_rec_status, lv_color_hex(0xFF8888), 0);

        xTaskCreatePinnedToCore(_rec_task, "rec_task",
                                8 * 1024, NULL, 6, NULL, 1);
    } else {
        /* FIX 3: reset timer immediately on STOP press */
        _rec_req_stop = true;
        lv_label_set_text(_rec_timer, "00:00:00");
        lv_label_set_text(_rec_status, "Saving...");
        lv_obj_set_style_text_color(_rec_status, lv_color_hex(0xFFDD55), 0);
    }
}

lv_obj_t *screen_recorder_create(lv_obj_t *tile)
{
    lv_obj_set_style_bg_color(tile, lv_color_hex(C_BG_MID), 0);
    lv_obj_set_style_bg_opa(tile, LV_OPA_COVER, 0);
    lv_obj_clear_flag(tile, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *title = lv_label_create(tile);
    lv_label_set_text(title, "Audio Recorder");
    lv_obj_set_style_text_font(title, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(title, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 30);

    lv_obj_t *acc = lv_obj_create(tile);
    lv_obj_set_size(acc, 160, 3);
    lv_obj_align(acc, LV_ALIGN_TOP_MID, 0, 70);
    lv_obj_set_style_bg_color(acc, lv_color_hex(C_ACCENT), 0);
    lv_obj_set_style_border_width(acc, 0, 0);
    lv_obj_set_style_radius(acc, 2, 0);
    lv_obj_clear_flag(acc, LV_OBJ_FLAG_SCROLLABLE);

    _rec_timer = lv_label_create(tile);
    lv_label_set_text(_rec_timer, "00:00:00");
    lv_obj_set_style_text_font(_rec_timer, &lv_font_montserrat_40, 0);
    lv_obj_set_style_text_color(_rec_timer, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_align(_rec_timer, LV_ALIGN_CENTER, 0, -80);

    _rec_btn = lv_btn_create(tile);
    lv_obj_set_size(_rec_btn, BTN_W_FULL, BTN_H);
    lv_obj_align(_rec_btn, LV_ALIGN_CENTER, 0, 20);
    lv_obj_set_style_radius(_rec_btn, BTN_H / 2, LV_PART_MAIN);
    lv_obj_set_style_bg_color(_rec_btn, lv_color_hex(C_GREEN_BTN),
                              LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(_rec_btn, lv_color_hex(C_GREEN_BTN_PR),
                              LV_PART_MAIN | LV_STATE_PRESSED);
    lv_obj_set_style_shadow_width(_rec_btn, 20, LV_PART_MAIN);
    lv_obj_set_style_shadow_color(_rec_btn, lv_color_hex(C_GREEN_BTN), LV_PART_MAIN);
    lv_obj_add_event_cb(_rec_btn, _rec_btn_cb, LV_EVENT_CLICKED, NULL);

    _rec_btn_lbl = lv_label_create(_rec_btn);
    lv_label_set_text(_rec_btn_lbl, LV_SYMBOL_AUDIO "  REC");
    lv_obj_set_style_text_font(_rec_btn_lbl, &lv_font_montserrat_20, 0);
    lv_obj_set_style_text_color(_rec_btn_lbl, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_center(_rec_btn_lbl);

    _rec_status = lv_label_create(tile);
    lv_label_set_long_mode(_rec_status, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(_rec_status, DISP_W - 80);
    lv_label_set_text(_rec_status, "Press REC to start recording");
    lv_obj_set_style_text_font(_rec_status, &lv_font_montserrat_16, 0);
    lv_obj_set_style_text_color(_rec_status, lv_color_hex(C_TEXT_DIM), 0);
    lv_obj_set_style_text_align(_rec_status, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(_rec_status, LV_ALIGN_BOTTOM_MID, 0, -30);

    return tile;
}

void screen_recorder_update(lv_obj_t *tile)
{
    (void)tile;
}
