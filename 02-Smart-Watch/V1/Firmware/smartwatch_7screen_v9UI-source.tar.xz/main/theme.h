/*
 * ================================================================
 *  theme.h — Shared visual constants
 *  Matches the dark deep-blue theme from the Arduino smartwatch UI.
 * ================================================================
 *
 *  SCREEN LAYOUT RULES (480 × 480 display)
 *  ─────────────────────────────────────────
 *  • Left  25 % (0–119 px)   = NAVIGATION ZONE — never place buttons here
 *  • Right 25 % (360–479 px) = NAVIGATION ZONE — never place buttons here
 *  • Center 50 % (120–359 px) = SAFE BUTTON ZONE
 *
 *  Always align interactive elements to LV_ALIGN_CENTER or
 *  LV_ALIGN_TOP_MID / LV_ALIGN_BOTTOM_MID with small offsets.
 *  Avoid lv_obj_set_pos() with hard x values < 120 or > 360.
 * ================================================================
 */

#pragma once
#include "lvgl.h"

/* ── Display size ────────────────────────────────────────── */
#define DISP_W  480
#define DISP_H  480

/* ── Navigation zones (pixels) ──────────────────────────── */
#define NAV_ZONE_W  120   /* 25 % of 480 */

/* ── Background palette ──────────────────────────────────── */
#define C_BG_DARK       0x050510   /* almost-black navy  */
#define C_BG_MID        0x0A0A1A   /* tile background    */
#define C_BG_PANEL      0x0D0D20   /* card / row bg      */
#define C_BG_TOPBAR     0x1A1A2E   /* header bars        */
#define C_BG_ITEM       0x1E1E35   /* list item default  */
#define C_BG_ITEM_PR    0x3E3E65   /* list item pressed  */
#define C_DIVIDER       0x1E3A5F   /* divider lines      */

/* ── Accent palette ──────────────────────────────────────── */
#define C_ACCENT        0x4FC3F7   /* sky-blue accent    */
#define C_ACCENT2       0x29B6F6   /* lighter blue       */
#define C_ACCENT_DARK   0x1A237E   /* deep-blue accent   */
#define C_BLUE_BTN      0x2255CC   /* primary button     */
#define C_BLUE_BTN_PR   0x1133AA   /* primary pressed    */
#define C_GREEN_BTN     0x22AA44   /* record/ok button   */
#define C_GREEN_BTN_PR  0x118833
#define C_RED_BTN       0xDD2222   /* stop/danger button */
#define C_PURPLE_ACCENT 0xAB47BC   /* gyro accent        */

/* ── Text palette ────────────────────────────────────────── */
#define C_TEXT_PRIMARY  0xFFFFFF
#define C_TEXT_BRIGHT   0xE3F2FD
#define C_TEXT_MID      0xCCCCCC
#define C_TEXT_SUB      0x90CAF9
#define C_TEXT_DIM      0x546E7A
#define C_TEXT_FAINT    0x37474F
#define C_TEXT_GHOST    0x1A1A3A
#define C_TEXT_GREEN    0x66EE66
#define C_TEXT_AUDIO    0x88AAFF   /* directory items    */

/* ── Helper macros ───────────────────────────────────────── */
#define THEME_BG(obj)  lv_obj_set_style_bg_color(obj, lv_color_hex(C_BG_MID), 0); \
                       lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, 0)

/* Pill button — centred, safe zone width */
#define BTN_W_FULL  220   /* fits in centre zone with margin */
#define BTN_H       72

/* Small button (e.g. topbar) */
#define BTN_W_SM    110
#define BTN_H_SM    48
