/*
 * features.h — Feature extraction for activity classifier
 * Target : ESP32-S3  (ESP-IDF, plain C)
 *
 * Window : 50 samples @ 100 Hz = 500 ms
 * Output : 84 float features  (fed to model.h predict())
 *
 * Usage:
 *   #include "features.h"
 *   #include "model.h"
 *
 *   float window[WINDOW_SIZE][6];   // fill with sensor data
 *   float feats[NUM_FEATURES];
 *   compute_features(window, feats);
 *   int label = predict(feats);     // 0=sitting 1=walking
 */
#ifndef FEATURES_H
#define FEATURES_H

#include <math.h>
#include <string.h>

#define WINDOW_SIZE   50    /* rows per classification window      */
#define SENSOR_AXES   6               /* ACC_X,Y,Z  GYR_X,Y,Z               */
#define NUM_FEATURES  84    /* total floats fed to predict()       */

/* Axis indices inside window[][SENSOR_AXES] */
#define AX  0   /* ACC_X  */
#define AY  1   /* ACC_Y  */
#define AZ  2   /* ACC_Z  */
#define GX  3   /* GYR_X  */
#define GY  4   /* GYR_Y  */
#define GZ  5   /* GYR_Z  */

/* Class label returned by predict() */
#define LABEL_SITTING 0
#define LABEL_WALKING 1

/* ── Internal helpers ──────────────────────────────────────────── */
static inline float _mean(const float *s, int n) {
    float sum = 0; for (int i=0;i<n;i++) sum+=s[i]; return sum/n;
}
static inline float _std(const float *s, int n, float mean) {
    float sum=0; for(int i=0;i<n;i++) {float d=s[i]-mean; sum+=d*d;} return sqrtf(sum/n);
}
static inline float _min(const float *s, int n) {
    float v=s[0]; for(int i=1;i<n;i++) if(s[i]<v) v=s[i]; return v;
}
static inline float _max(const float *s, int n) {
    float v=s[0]; for(int i=1;i<n;i++) if(s[i]>v) v=s[i]; return v;
}
static inline float _energy(const float *s, int n) {
    float e=0; for(int i=0;i<n;i++) e+=s[i]*s[i]; return e;
}
static inline float _rms(const float *s, int n) {
    return sqrtf(_energy(s,n)/n);
}
static inline float _iqr(const float *s, int n) {
    /* Simple linear interpolation percentile */
    /* Make a sorted copy on stack — n <= 50 so stack is fine */
    float tmp[WINDOW_SIZE];
    memcpy(tmp, s, n*sizeof(float));
    /* Insertion sort (n is small) */
    for(int i=1;i<n;i++){
        float key=tmp[i]; int j=i-1;
        while(j>=0 && tmp[j]>key){tmp[j+1]=tmp[j]; j--;}
        tmp[j+1]=key;
    }
    float p25=(tmp[n/4]+tmp[(n-1)/4])*0.5f;
    float p75=(tmp[3*n/4]+tmp[(3*(n-1))/4])*0.5f;
    return p75-p25;
}
static inline int _zero_crossings(const float *s, int n, float mean) {
    int zc=0;
    for(int i=1;i<n;i++)
        if(((s[i-1]-mean)>=0) != ((s[i]-mean)>=0)) zc++;
    return zc;
}
static inline int _peak_count(const float *s, int n) {
    int pc=0;
    for(int i=1;i<n-1;i++)
        if(s[i]>s[i-1] && s[i]>s[i+1]) pc++;
    return pc;
}
static inline float _entropy(const float *s, int n) {
    /* 8-bin histogram entropy */
    float mn=_min(s,n), mx=_max(s,n);
    float range=mx-mn; if(range<1e-6f) range=1e-6f;
    float hist[8]={0};
    for(int i=0;i<n;i++){
        int bin=(int)((s[i]-mn)/range*7.99f);
        if(bin<0)bin=0; 
        if(bin>7)bin=7;
        hist[bin]+=1.0f/n;
    }
    float ent=0;
    for(int b=0;b<8;b++){
        float h=hist[b]+1e-10f;
        ent-=h*logf(h);
    }
    return ent;
}
static inline float _mean_jerk(const float *s, int n) {
    float sum=0;
    for(int i=1;i<n;i++) sum+=fabsf(s[i]-s[i-1]);
    return sum/(n-1);
}
static inline float _std_jerk(const float *s, int n) {
    float mj=_mean_jerk(s,n), sum=0;
    for(int i=1;i<n;i++){float d=fabsf(s[i]-s[i-1])-mj; sum+=d*d;}
    return sqrtf(sum/(n-1));
}
static inline float _corrcoef(const float *a, const float *b, int n) {
    float ma=_mean(a,n), mb=_mean(b,n);
    float num=0, da2=0, db2=0;
    for(int i=0;i<n;i++){
        float da=a[i]-ma, db=b[i]-mb;
        num+=da*db; da2+=da*da; db2+=db*db;
    }
    float denom=sqrtf(da2*db2);
    return (denom<1e-10f)?0.0f:(num/denom);
}

/* ── Main feature computation function ────────────────────────── */
/**
 * compute_features()
 *
 * @param  window   [WINDOW_SIZE][6]  raw sensor values
 *                  columns: ACC_X(0) ACC_Y(1) ACC_Z(2)
 *                           GYR_X(3) GYR_Y(4) GYR_Z(5)
 * @param  out      [NUM_FEATURES]    output feature vector
 *
 * Call predict(out) from model.h immediately after.
 */
static inline void compute_features(const float window[WINDOW_SIZE][SENSOR_AXES],
                                    float out[NUM_FEATURES])
{
    int idx = 0;

    /* ── Per-axis features (13 per axis × 6 axes = 78) ── */
    for (int ax = 0; ax < SENSOR_AXES; ax++) {
        /* Extract column into a local array */
        float col[WINDOW_SIZE];
        for (int r = 0; r < WINDOW_SIZE; r++) col[r] = window[r][ax];

        float m  = _mean(col, WINDOW_SIZE);

        out[idx++] = m;                                      /* mean       */
        out[idx++] = _std(col, WINDOW_SIZE, m);              /* std        */
        out[idx++] = _min(col, WINDOW_SIZE);                 /* min        */
        out[idx++] = _max(col, WINDOW_SIZE);                 /* max        */
        out[idx++] = _max(col,WINDOW_SIZE)-_min(col,WINDOW_SIZE); /* range */
        out[idx++] = _energy(col, WINDOW_SIZE);              /* energy     */
        out[idx++] = _rms(col, WINDOW_SIZE);                 /* rms        */
        out[idx++] = _iqr(col, WINDOW_SIZE);                 /* iqr        */
        out[idx++] = _mean_jerk(col, WINDOW_SIZE);           /* mean_jerk  */
        out[idx++] = _std_jerk(col, WINDOW_SIZE);            /* std_jerk   */
        out[idx++] = (float)_zero_crossings(col, WINDOW_SIZE, m); /* zero_cross */
        out[idx++] = (float)_peak_count(col, WINDOW_SIZE);   /* peaks      */
        out[idx++] = _entropy(col, WINDOW_SIZE);              /* entropy    */
    }

    /* ── Cross-axis features (6) ── */
    /* Accelerometer magnitude std */
    float acc_mag[WINDOW_SIZE];
    for (int r = 0; r < WINDOW_SIZE; r++)
        acc_mag[r] = sqrtf(window[r][AX]*window[r][AX] +
                           window[r][AY]*window[r][AY] +
                           window[r][AZ]*window[r][AZ]);
    float mean_am = _mean(acc_mag, WINDOW_SIZE);
    out[idx++] = _std(acc_mag, WINDOW_SIZE, mean_am);   /* std_acc_mag  */

    /* Gyroscope magnitude std */
    float gyr_mag[WINDOW_SIZE];
    for (int r = 0; r < WINDOW_SIZE; r++)
        gyr_mag[r] = sqrtf(window[r][GX]*window[r][GX] +
                           window[r][GY]*window[r][GY] +
                           window[r][GZ]*window[r][GZ]);
    float mean_gm = _mean(gyr_mag, WINDOW_SIZE);
    out[idx++] = _std(gyr_mag, WINDOW_SIZE, mean_gm);   /* std_gyro_mag */

    /* Acc axis correlations */
    float ax_col[WINDOW_SIZE], ay_col[WINDOW_SIZE], az_col[WINDOW_SIZE];
    for (int r = 0; r < WINDOW_SIZE; r++) {
        ax_col[r] = window[r][AX];
        ay_col[r] = window[r][AY];
        az_col[r] = window[r][AZ];
    }
    out[idx++] = _corrcoef(ax_col, ay_col, WINDOW_SIZE); /* corr_acc_xy */
    out[idx++] = _corrcoef(ax_col, az_col, WINDOW_SIZE); /* corr_acc_xz */
    out[idx++] = _corrcoef(ay_col, az_col, WINDOW_SIZE); /* corr_acc_yz */

    /* Gyro total angular displacement */
    float gyro_disp = 0.0f;
    for (int r = 1; r < WINDOW_SIZE; r++) {
        gyro_disp += fabsf(window[r][GX]-window[r-1][GX]);
        gyro_disp += fabsf(window[r][GY]-window[r-1][GY]);
        gyro_disp += fabsf(window[r][GZ]-window[r-1][GZ]);
    }
    out[idx++] = gyro_disp;                               /* gyro_disp   */

    /* Sanity check — remove for production */
    /* assert(idx == NUM_FEATURES); */
}

#endif /* FEATURES_H */
