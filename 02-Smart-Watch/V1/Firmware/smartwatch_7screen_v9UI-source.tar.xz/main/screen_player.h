/*
 * ================================================================
 *  screen_player.h — Screen 4: File Browser + Audio Player
 *
 *  FIX 5: Back button (← ) in top bar — navigates up one folder
 *  FIX 6: Blocks playback if recording is active (g_audio_busy)
 *
 *  Top bar layout (left→right):
 *    [← Back]   [Audio Player / current path]   [■ STOP / ▶ PLAY]
 * ================================================================
 */
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "lvgl.h"
#include "audio_player.h"
#include "bsp/esp-bsp.h"
#include "theme.h"

/* FIX 6: shared audio state from main.c */
extern volatile int g_audio_busy;

#define PLY_TAG        "Screen_Ply"
#define PLY_ROOT       "/sdcard"
#define PLY_TOPBAR_H   60
#define PLY_LIST_H     (DISP_H - PLY_TOPBAR_H)

/* State */
typedef enum { PLY_IDLE = 0, PLY_PLAYING } ply_st_t;
static volatile ply_st_t _ply_state = PLY_IDLE;
static char _ply_cur_dir[256];

/* Widget handles */
static lv_obj_t *_ply_tile_ref = NULL;
static lv_obj_t *_ply_stop_btn = NULL;
static lv_obj_t *_ply_stop_lbl = NULL;

/* Forward declaration */
void _ply_rebuild_browser(lv_obj_t *tile, const char *path);

static bool _ply_is_audio(const char *name)
{
    const char *ext = strrchr(name, '.');
    if (!ext) return false;
    char low[8] = {0};
    for (int i = 0; i < 7 && ext[i]; i++) low[i] = (char)(ext[i] | 0x20);
    return strcmp(low, ".wav") == 0 || strcmp(low, ".mp3") == 0;
}

/* Audio end-of-track callback */
static void _ply_audio_cb(audio_player_cb_ctx_t *ctx)
{
    if (ctx->audio_event == AUDIO_PLAYER_CALLBACK_EVENT_IDLE) {
        _ply_state   = PLY_IDLE;
        g_audio_busy = 0;   /* FIX 6: release lock */
        if (bsp_display_lock(pdMS_TO_TICKS(100))) {
            if (_ply_stop_btn && lv_obj_is_valid(_ply_stop_btn)) {
                lv_obj_set_style_bg_color(_ply_stop_btn, lv_color_hex(C_BLUE_BTN),
                                          LV_PART_MAIN | LV_STATE_DEFAULT);
                lv_label_set_text(_ply_stop_lbl, LV_SYMBOL_PLAY "  PLAY");
            }
            bsp_display_unlock();
        }
    }
}

/* Stop button callback */
static void _ply_stop_cb(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    if (_ply_state == PLY_PLAYING) {
        audio_player_stop();
        _ply_state   = PLY_IDLE;
        g_audio_busy = 0;   /* FIX 6: release lock */
        lv_obj_set_style_bg_color(_ply_stop_btn, lv_color_hex(C_BLUE_BTN),
                                  LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_label_set_text(_ply_stop_lbl, LV_SYMBOL_PLAY "  PLAY");
    }
}

/* FIX 5: Back button callback — navigate up one folder */
static void _ply_back_cb(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;

    /* Already at root — nothing to do */
    if (strcmp(_ply_cur_dir, PLY_ROOT) == 0) return;

    /* Trim last path component */
    char parent[256];
    strncpy(parent, _ply_cur_dir, sizeof(parent) - 1);
    char *slash = strrchr(parent, '/');
    if (slash && slash != parent) {
        *slash = '\0';
    } else {
        /* safety fallback */
        strncpy(parent, PLY_ROOT, sizeof(parent) - 1);
    }
    /* Don't go above PLY_ROOT */
    if (strlen(parent) < strlen(PLY_ROOT)) {
        strncpy(parent, PLY_ROOT, sizeof(parent) - 1);
    }
    _ply_rebuild_browser(_ply_tile_ref, parent);
}

/* File/folder tap callback */
static void _ply_file_cb(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    const char *p = (const char *)lv_event_get_user_data(e);
    if (!p) return;

    struct stat st;
    if (stat(p, &st) != 0) return;

    if (S_ISDIR(st.st_mode)) {
        strncpy(_ply_cur_dir, p, sizeof(_ply_cur_dir) - 1);
        _ply_rebuild_browser(_ply_tile_ref, p);
        return;
    }

    const char *fname = strrchr(p, '/');
    fname = fname ? fname + 1 : p;
    if (!_ply_is_audio(fname)) return;

    /* FIX 6: block if recording is active */
    if (g_audio_busy == 1) {
        /* Show brief message — rebuild so the status is visible */
        ESP_LOGW(PLY_TAG, "Cannot play: recording in progress");
        /* Display a toast-style message at bottom of screen */
        if (bsp_display_lock(pdMS_TO_TICKS(100))) {
            /* Reuse stop label as temp message */
            if (_ply_stop_btn && lv_obj_is_valid(_ply_stop_btn)) {
                lv_label_set_text(_ply_stop_lbl, "Busy!");
            }
            bsp_display_unlock();
        }
        return;
    }

    if (_ply_state == PLY_PLAYING) {
        audio_player_stop();
        _ply_state = PLY_IDLE;
        vTaskDelay(pdMS_TO_TICKS(60));
    }

    FILE *fp = fopen(p, "rb");
    if (!fp) { ESP_LOGE(PLY_TAG, "Cannot open %s", p); return; }

    if (audio_player_play(fp) == ESP_OK) {
        _ply_state   = PLY_PLAYING;
        g_audio_busy = 2;   /* FIX 6: claim lock as playing */
        lv_obj_set_style_bg_color(_ply_stop_btn, lv_color_hex(C_RED_BTN),
                                  LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_label_set_text(_ply_stop_lbl, LV_SYMBOL_STOP "  STOP");
    } else {
        fclose(fp);
    }
}

/* Build / rebuild browser */
void _ply_rebuild_browser(lv_obj_t *tile, const char *path)
{
    strncpy(_ply_cur_dir, path, sizeof(_ply_cur_dir) - 1);
    _ply_tile_ref = tile;

    lv_obj_clean(tile);
    lv_obj_set_style_bg_color(tile, lv_color_hex(C_BG_DARK), 0);
    lv_obj_set_style_bg_opa(tile, LV_OPA_COVER, 0);
    lv_obj_clear_flag(tile, LV_OBJ_FLAG_SCROLLABLE);

    /* ══ TOP BAR ══ */
    lv_obj_t *bar = lv_obj_create(tile);
    lv_obj_set_size(bar, DISP_W, PLY_TOPBAR_H);
    lv_obj_set_pos(bar, 0, 0);
    lv_obj_set_style_bg_color(bar, lv_color_hex(C_BG_TOPBAR), 0);
    lv_obj_set_style_border_width(bar, 0, 0);
    lv_obj_set_style_radius(bar, 0, 0);
    lv_obj_set_style_pad_all(bar, 0, 0);
    lv_obj_clear_flag(bar, LV_OBJ_FLAG_SCROLLABLE);

    /* FIX 5: Back button — left side of bar */
    bool at_root = (strcmp(_ply_cur_dir, PLY_ROOT) == 0);
    lv_obj_t *back_btn = lv_btn_create(bar);
    lv_obj_set_size(back_btn, BTN_W_SM, BTN_H_SM - 4);
    lv_obj_align(back_btn, LV_ALIGN_LEFT_MID, 130, 0); /* x=130 → inside safe zone */
    lv_obj_set_style_radius(back_btn, 8, LV_PART_MAIN);
    lv_obj_set_style_bg_color(back_btn,
        at_root ? lv_color_hex(0x333355)   /* dimmed at root */
                : lv_color_hex(C_BLUE_BTN),
        LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(back_btn, lv_color_hex(C_BLUE_BTN_PR),
                              LV_PART_MAIN | LV_STATE_PRESSED);
    if (!at_root)
        lv_obj_add_event_cb(back_btn, _ply_back_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *back_lbl = lv_label_create(back_btn);
    lv_label_set_text(back_lbl, LV_SYMBOL_LEFT " Back");
    lv_obj_set_style_text_font(back_lbl, &lv_font_montserrat_14, 0);
    lv_obj_set_style_text_color(back_lbl,
        at_root ? lv_color_hex(C_TEXT_FAINT)
                : lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_center(back_lbl);

    /* Title centred in bar */
    lv_obj_t *title = lv_label_create(bar);
    /* Show just the last folder name, or "Audio Player" at root */
    const char *disp;
    if (at_root) {
        disp = "Audio Player";
    } else {
        disp = strrchr(_ply_cur_dir, '/');
        disp = disp ? disp + 1 : _ply_cur_dir;
    }
    lv_label_set_text(title, disp);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_16, 0);
    lv_obj_set_style_text_color(title, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_label_set_long_mode(title, LV_LABEL_LONG_DOT);
    lv_obj_set_width(title, 130);
    lv_obj_align(title, LV_ALIGN_CENTER, 0, 0);

    /* PLAY/STOP button — right side of bar */
    _ply_stop_btn = lv_btn_create(bar);
    lv_obj_set_size(_ply_stop_btn, BTN_W_SM, BTN_H_SM - 4);
    lv_obj_align(_ply_stop_btn, LV_ALIGN_RIGHT_MID, -130, 0); /* x≈240, inside safe zone */
    lv_obj_set_style_radius(_ply_stop_btn, 8, LV_PART_MAIN);
    lv_obj_set_style_bg_color(_ply_stop_btn,
        (_ply_state == PLY_PLAYING) ? lv_color_hex(C_RED_BTN)
                                    : lv_color_hex(C_BLUE_BTN),
        LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(_ply_stop_btn, lv_color_hex(C_BLUE_BTN_PR),
                              LV_PART_MAIN | LV_STATE_PRESSED);
    lv_obj_add_event_cb(_ply_stop_btn, _ply_stop_cb, LV_EVENT_CLICKED, NULL);

    _ply_stop_lbl = lv_label_create(_ply_stop_btn);
    lv_obj_set_style_text_font(_ply_stop_lbl, &lv_font_montserrat_14, 0);
    lv_obj_set_style_text_color(_ply_stop_lbl, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_label_set_text(_ply_stop_lbl,
        (_ply_state == PLY_PLAYING) ? LV_SYMBOL_STOP "  STOP"
                                    : LV_SYMBOL_PLAY "  PLAY");
    lv_obj_center(_ply_stop_lbl);

    /* ══ FILE LIST ══ */
    lv_obj_t *list = lv_list_create(tile);
    lv_obj_set_size(list, DISP_W, PLY_LIST_H);
    lv_obj_set_pos(list, 0, PLY_TOPBAR_H);
    lv_obj_set_style_bg_color(list, lv_color_hex(C_BG_DARK), 0);
    lv_obj_set_style_border_width(list, 0, 0);
    lv_obj_set_style_radius(list, 0, 0);
    lv_obj_set_style_pad_row(list, 6, 0);
    lv_obj_set_style_pad_left(list, 8, 0);
    lv_obj_set_style_pad_right(list, 8, 0);
    lv_obj_set_style_pad_top(list, 8, 0);

    DIR *dir = opendir(path);
    if (!dir) {
        lv_obj_t *err = lv_label_create(list);
        lv_label_set_text(err, "Cannot open directory");
        lv_obj_set_style_text_color(err, lv_color_hex(0xFF4444), 0);
        return;
    }

    typedef struct { char name[256]; bool is_dir; } ent_t;
    int cnt = 0, cap = 16;
    ent_t *ents = (ent_t *)malloc(cap * sizeof(ent_t));

    struct dirent *de;
    while ((de = readdir(dir)) != NULL) {
        if (de->d_name[0] == '.') continue;
        if (cnt >= cap) { cap *= 2; ents = (ent_t *)realloc(ents, cap * sizeof(ent_t)); }
        strncpy(ents[cnt].name, de->d_name, 255);
        ents[cnt].is_dir = (de->d_type == DT_DIR);
        cnt++;
    }
    closedir(dir);

    /* Sort: dirs first, then alpha */
    for (int i = 0; i < cnt - 1; i++)
        for (int j = i + 1; j < cnt; j++) {
            bool sw = (ents[j].is_dir && !ents[i].is_dir) ||
                      (ents[i].is_dir == ents[j].is_dir &&
                       strcmp(ents[i].name, ents[j].name) > 0);
            if (sw) { ent_t tmp = ents[i]; ents[i] = ents[j]; ents[j] = tmp; }
        }

    if (cnt == 0) {
        lv_obj_t *empty = lv_label_create(list);
        lv_label_set_text(empty, "(empty folder)");
        lv_obj_set_style_text_color(empty, lv_color_hex(C_TEXT_DIM), 0);
        lv_obj_set_style_text_font(empty, &lv_font_montserrat_16, 0);
        lv_obj_align(empty, LV_ALIGN_CENTER, 0, 0);
    }

    for (int i = 0; i < cnt; i++) {
        char *full = (char *)malloc(strlen(path) + strlen(ents[i].name) + 2);
        sprintf(full, "%s/%s", path, ents[i].name);

        const char *icon;
        lv_color_t  col;
        if (ents[i].is_dir)                   { icon = LV_SYMBOL_DIRECTORY; col = lv_color_hex(C_TEXT_AUDIO);  }
        else if (_ply_is_audio(ents[i].name)) { icon = LV_SYMBOL_AUDIO;     col = lv_color_hex(C_TEXT_GREEN);  }
        else                                   { icon = LV_SYMBOL_FILE;      col = lv_color_hex(C_TEXT_DIM);    }

        lv_obj_t *btn = lv_list_add_btn(list, icon, ents[i].name);
        lv_obj_set_style_bg_color(btn, lv_color_hex(C_BG_ITEM),
                                  LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_bg_color(btn, lv_color_hex(C_BG_ITEM_PR),
                                  LV_PART_MAIN | LV_STATE_PRESSED);
        lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_style_radius(btn, 8, LV_PART_MAIN);
        lv_obj_set_height(btn, 54);

        uint32_t nc = lv_obj_get_child_count(btn);
        for (uint32_t c = 0; c < nc; c++) {
            lv_obj_t *ch = lv_obj_get_child(btn, c);
            lv_obj_set_style_text_color(ch, col, 0);
            lv_obj_set_style_text_font(ch, &lv_font_montserrat_16, 0);
        }
        lv_obj_add_event_cb(btn, _ply_file_cb, LV_EVENT_CLICKED, (void *)full);
    }
    free(ents);
}

lv_obj_t *screen_player_create(lv_obj_t *tile)
{
    static bool _cb_reg = false;
    if (!_cb_reg) {
        bsp_extra_player_register_callback(_ply_audio_cb, NULL);
        _cb_reg = true;
    }
    strncpy(_ply_cur_dir, PLY_ROOT, sizeof(_ply_cur_dir) - 1);
    _ply_rebuild_browser(tile, PLY_ROOT);
    return tile;
}

void screen_player_update(lv_obj_t *tile)
{
    (void)tile;
}
