/*
 * ================================================================
 *  screen_imu.h — Screen 2: IMU (Accelerometer + Gyroscope)
 *
 *  FIX 2: update called at 3 Hz by fast_update_task in main.c
 *  FIX 2: value format matches CSV: ACC_X,ACC_Y,ACC_Z,GYR_X,GYR_Y,GYR_Z
 *          Accel: 2 decimal places (e.g. -0.28)
 *          Gyro:  2 decimal places (e.g. 25.50)
 * ================================================================
 */
#pragma once
#include "lvgl.h"
#include "theme.h"
#include "bsp/esp-bsp.h"
#include "driver/i2c_master.h"
#include "esp_log.h"

#define IMU_TAG            "IMU"
#define QMI8658_ADDR       0x6B
#define QMI8658_ACC_SCALE  (4.0f   / 32768.0f)   /* ±4g     */
#define QMI8658_GYR_SCALE  (512.0f / 32768.0f)   /* ±512dps */

i2c_master_dev_handle_t g_imu_dev   = NULL;
bool                    g_imu_ready = false;
/* aliases so rest of file unchanged */
#define _imu_dev   g_imu_dev
#define _imu_ready g_imu_ready

static esp_err_t _imu_write_reg(uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = { reg, val };
    return i2c_master_transmit(_imu_dev, buf, 2, pdMS_TO_TICKS(20));
}

static esp_err_t _imu_read_regs(uint8_t reg, uint8_t *out, size_t len)
{
    return i2c_master_transmit_receive(_imu_dev, &reg, 1, out, len,
                                       pdMS_TO_TICKS(20));
}

static void _imu_init(void)
{
    i2c_master_bus_handle_t bus = bsp_i2c_get_handle();
    if (!bus) { ESP_LOGE(IMU_TAG, "BSP I2C bus handle is NULL"); return; }

    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address  = QMI8658_ADDR,
        .scl_speed_hz    = 400000,
    };
    if (i2c_master_bus_add_device(bus, &dev_cfg, &_imu_dev) != ESP_OK) {
        ESP_LOGE(IMU_TAG, "Failed to add QMI8658"); return;
    }

    _imu_write_reg(0x02, 0x40);
    _imu_write_reg(0x03, 0x73);
    _imu_write_reg(0x04, 0xD3);
    _imu_write_reg(0x08, 0x03);

    _imu_ready = true;
    ESP_LOGI(IMU_TAG, "QMI8658 initialised");
}

static void _imu_read6(uint8_t start_reg, float scale,
                        float *x, float *y, float *z)
{
    uint8_t raw[6] = {0};
    if (_imu_read_regs(start_reg, raw, 6) != ESP_OK) {
        *x = *y = *z = 0.0f; return;
    }
    *x = (int16_t)((raw[1] << 8) | raw[0]) * scale;
    *y = (int16_t)((raw[3] << 8) | raw[2]) * scale;
    *z = (int16_t)((raw[5] << 8) | raw[4]) * scale;
}

/* Widget handles */
static lv_obj_t *_imu_ax=NULL, *_imu_ay=NULL, *_imu_az=NULL;
static lv_obj_t *_imu_gx=NULL, *_imu_gy=NULL, *_imu_gz=NULL;

static lv_obj_t *_imu_make_row(lv_obj_t *parent, const char *name,
                                lv_color_t accent, int y_off)
{
    lv_obj_t *row = lv_obj_create(parent);
    lv_obj_set_size(row, 340, 52);
    lv_obj_align(row, LV_ALIGN_TOP_MID, 0, y_off);
    lv_obj_set_style_bg_color(row, lv_color_hex(C_BG_PANEL), 0);
    lv_obj_set_style_border_color(row, accent, 0);
    lv_obj_set_style_border_width(row, 1, 0);
    lv_obj_set_style_border_side(row, LV_BORDER_SIDE_LEFT, 0);
    lv_obj_set_style_border_opa(row, LV_OPA_80, 0);
    lv_obj_set_style_radius(row, 6, 0);
    lv_obj_set_style_pad_left(row, 14, 0);
    lv_obj_set_style_pad_right(row, 14, 0);
    lv_obj_set_style_pad_top(row, 0, 0);
    lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *ln = lv_label_create(row);
    lv_label_set_text(ln, name);
    lv_obj_set_style_text_color(ln, accent, 0);
    lv_obj_set_style_text_font(ln, &lv_font_montserrat_14, 0);
    lv_obj_align(ln, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *lv2 = lv_label_create(row);
    lv_label_set_text(lv2, "---");
    lv_obj_set_style_text_color(lv2, lv_color_hex(0xE0E0E0), 0);
    lv_obj_set_style_text_font(lv2, &lv_font_montserrat_20, 0);
    lv_obj_align(lv2, LV_ALIGN_RIGHT_MID, 0, 0);
    return lv2;
}

lv_obj_t *screen_imu_create(lv_obj_t *tile)
{
    lv_obj_set_style_bg_color(tile, lv_color_hex(C_BG_DARK), 0);
    lv_obj_set_style_bg_opa(tile, LV_OPA_COVER, 0);
    lv_obj_clear_flag(tile, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *tag = lv_label_create(tile);
    lv_label_set_text(tag, "IMU");
    lv_obj_set_style_text_font(tag, &lv_font_montserrat_12, 0);
    lv_obj_set_style_text_color(tag, lv_color_hex(C_ACCENT_DARK), 0);
    lv_obj_align(tag, LV_ALIGN_TOP_MID, 0, 8);

    lv_obj_t *ha = lv_label_create(tile);
    lv_label_set_text(ha, LV_SYMBOL_CHARGE "  ACCELEROMETER  (g)");
    lv_obj_set_style_text_color(ha, lv_color_hex(C_ACCENT2), 0);
    lv_obj_set_style_text_font(ha, &lv_font_montserrat_12, 0);
    lv_obj_align(ha, LV_ALIGN_TOP_MID, 0, 30);

    lv_color_t ca = lv_color_hex(0x0288D1);
    /* FIX 2: label names match CSV header */
    _imu_ax = _imu_make_row(tile, "ACC_X", ca,  52);
    _imu_ay = _imu_make_row(tile, "ACC_Y", ca, 108);
    _imu_az = _imu_make_row(tile, "ACC_Z", ca, 164);

    lv_obj_t *hg = lv_label_create(tile);
    lv_label_set_text(hg, LV_SYMBOL_LOOP "  GYROSCOPE  (dps)");
    lv_obj_set_style_text_color(hg, lv_color_hex(C_PURPLE_ACCENT), 0);
    lv_obj_set_style_text_font(hg, &lv_font_montserrat_12, 0);
    lv_obj_align(hg, LV_ALIGN_TOP_MID, 0, 232);

    lv_color_t cg = lv_color_hex(0x7B1FA2);
    _imu_gx = _imu_make_row(tile, "GYR_X", cg, 256);
    _imu_gy = _imu_make_row(tile, "GYR_Y", cg, 312);
    _imu_gz = _imu_make_row(tile, "GYR_Z", cg, 368);

    _imu_init();
    return tile;
}

void screen_imu_update(lv_obj_t *tile)
{
    (void)tile;
    if (!_imu_ready || !_imu_ax) return;

    float ax, ay, az, gx, gy, gz;
    _imu_read6(0x35, QMI8658_ACC_SCALE, &ax, &ay, &az);
    _imu_read6(0x3B, QMI8658_GYR_SCALE, &gx, &gy, &gz);

    char b[16];
    /* FIX 2: 2 decimal places to match CSV format */
    snprintf(b, sizeof(b), "%+.2f", ax); lv_label_set_text(_imu_ax, b);
    snprintf(b, sizeof(b), "%+.2f", ay); lv_label_set_text(_imu_ay, b);
    snprintf(b, sizeof(b), "%+.2f", az); lv_label_set_text(_imu_az, b);
    snprintf(b, sizeof(b), "%+.2f", gx); lv_label_set_text(_imu_gx, b);
    snprintf(b, sizeof(b), "%+.2f", gy); lv_label_set_text(_imu_gy, b);
    snprintf(b, sizeof(b), "%+.2f", gz); lv_label_set_text(_imu_gz, b);
}
