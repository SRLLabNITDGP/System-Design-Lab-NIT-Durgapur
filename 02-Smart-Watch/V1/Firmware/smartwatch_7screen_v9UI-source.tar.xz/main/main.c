/*
 * ================================================================
 *  main.c — SmartWatch 5-Screen  (ESP-IDF)
 *  Board: ESP32-S3-Touch-AMOLED-2.06
 *  Display: 480 × 480  AMOLED
 * ================================================================
 *
 *  BUG FIXES in this version:
 *  FIX 1: RTC (PCF85063) read at boot via settimeofday()
 *  FIX 2: IMU updated at 3 Hz via separate fast task
 *  FIX 6: g_audio_busy flag blocks simultaneous rec+play
 *
 * ================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_timer.h"

#include "lvgl.h"
#include "bsp/esp-bsp.h"
#include "bsp_board_extra.h"
#include "audio_player.h"
#include "driver/i2c_master.h"
#include "nvs_flash.h"
#include "nvs.h"

#include "screen_manager.h"
#include "screen_home.h"
#include "screen_clock.h"
#include "screen_imu.h"
#include "screen_recorder.h"
#include "screen_player.h"
#include "screen_imu_logger.h"
#include "screen_classifier.h"

#define LVGL_PORT_INIT_CONFIG()   \
    {                             \
        .task_priority = 4,       \
        .task_stack = 10 * 1024,  \
        .task_affinity = -1,      \
        .task_max_sleep_ms = 500, \
        .timer_period_ms = 5,     \
    }

static const char *TAG = "main";

/* Global screen manager instance */
screen_manager_t g_sm = {0};

/*
 * FIX 6: Shared audio-busy flag
 *  0 = idle
 *  1 = recording
 *  2 = playing
 * Both screen_recorder.h and screen_player.h read/write this.
 */
volatile int g_audio_busy = 0;

/* ─────────────────────────────────────────────────────────
   FIX 1: PCF85063 RTC read + settimeofday()
   Registers (BCD): 0x04=Sec 0x05=Min 0x06=Hr 0x07=Day
                    0x08=Wday 0x09=Mon 0x0A=Year(offset 2000)
   ───────────────────────────────────────────────────────── */
#define PCF85063_ADDR  0x51

static uint8_t _bcd2bin(uint8_t v) { return (v >> 4) * 10 + (v & 0x0F); }
static uint8_t _bin2bcd(uint8_t v) { return ((v / 10) << 4) | (v % 10); }

static void rtc_sync_to_system(void)
{
    i2c_master_bus_handle_t bus = bsp_i2c_get_handle();
    if (!bus) { ESP_LOGW(TAG, "RTC: no I2C bus"); return; }

    i2c_device_config_t cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address  = PCF85063_ADDR,
        .scl_speed_hz    = 400000,
    };
    i2c_master_dev_handle_t dev;
    if (i2c_master_bus_add_device(bus, &cfg, &dev) != ESP_OK) {
        ESP_LOGW(TAG, "RTC: cannot add device"); return;
    }

    uint8_t reg = 0x04, r[7] = {0};
    if (i2c_master_transmit_receive(dev, &reg, 1, r, 7,
                                    pdMS_TO_TICKS(50)) != ESP_OK) {
        ESP_LOGW(TAG, "RTC: read failed");
        i2c_master_bus_rm_device(dev);
        return;
    }
    i2c_master_bus_rm_device(dev);

    if (r[0] & 0x80)
        ESP_LOGW(TAG, "RTC oscillator stopped — time may be invalid");

    struct tm t = {
        .tm_sec  = _bcd2bin(r[0] & 0x7F),
        .tm_min  = _bcd2bin(r[1] & 0x7F),
        .tm_hour = _bcd2bin(r[2] & 0x3F),
        .tm_mday = _bcd2bin(r[3] & 0x3F),
        .tm_mon  = _bcd2bin(r[5] & 0x1F) - 1,
        .tm_year = _bcd2bin(r[6]) + 100,
        .tm_isdst = -1,
    };
    struct timeval tv = { .tv_sec = mktime(&t) + 16380, .tv_usec = 0 };
    settimeofday(&tv, NULL);
    ESP_LOGI(TAG, "RTC synced: %04d-%02d-%02d %02d:%02d:%02d",
             t.tm_year+1900, t.tm_mon+1, t.tm_mday,
             t.tm_hour, t.tm_min, t.tm_sec);
}

/* Write system time back to PCF85063 (used internally) */
void rtc_write_from_system(void)
{
    i2c_master_bus_handle_t bus = bsp_i2c_get_handle();
    if (!bus) return;
    i2c_device_config_t cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address  = PCF85063_ADDR,
        .scl_speed_hz    = 400000,
    };
    i2c_master_dev_handle_t dev;
    if (i2c_master_bus_add_device(bus, &cfg, &dev) != ESP_OK) return;
    time_t now; time(&now);
    struct tm t; localtime_r(&now, &t);
    uint8_t buf[8] = {
        0x04,
        _bin2bcd((uint8_t)t.tm_sec),
        _bin2bcd((uint8_t)t.tm_min),
        _bin2bcd((uint8_t)t.tm_hour),
        _bin2bcd((uint8_t)t.tm_mday),
        (uint8_t)t.tm_wday,
        _bin2bcd((uint8_t)(t.tm_mon + 1)),
        _bin2bcd((uint8_t)(t.tm_year - 100)),
    };
    i2c_master_transmit(dev, buf, 8, pdMS_TO_TICKS(50));
    i2c_master_bus_rm_device(dev);
}

/* ── UI init ─────────────────────────────────────────────── */
static void app_ui_init(void)
{
    screen_manager_register("Home",     screen_home_create,     screen_home_update);
    screen_manager_register("Clock",    screen_clock_create,    screen_clock_update);
    screen_manager_register("IMU",      screen_imu_create,      screen_imu_update);
    screen_manager_register("Recorder", screen_recorder_create, screen_recorder_update);
    screen_manager_register("Player",   screen_player_create,   screen_player_update);
    screen_manager_register("IMULog",   screen_imu_logger_create, screen_imu_logger_update);
    screen_manager_register("Classify", screen_classifier_create, screen_classifier_update);
    screen_manager_build();
}

/* ── FIX 2: 1 Hz slow update (all screens except IMU=2) ──── */
static void slow_update_task(void *pv)
{
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(1000));
        if (bsp_display_lock(pdMS_TO_TICKS(50))) {
            screen_manager_t *sm = &g_sm;
            if (sm->count > 0 && sm->tileview) {
                lv_obj_t *act = lv_tileview_get_tile_act(sm->tileview);
                for (int i = 0; i < sm->count; i++) {
                    if (sm->screens[i].tile == act) {
                        sm->active_idx = i;
                        if (i != 2 && i != 5 && i != 6 && sm->screens[i].update)
                            sm->screens[i].update(sm->screens[i].tile);
                        break;
                    }
                }
            }
            bsp_display_unlock();
        }
    }
}

/* ── FIX 2: 3 Hz fast update (IMU screen only) ──────────── */
static void fast_update_task(void *pv)
{
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(333));
        if (g_sm.active_idx == 2) {
            if (bsp_display_lock(pdMS_TO_TICKS(30))) {
                screen_manager_t *sm = &g_sm;
                if (sm->count > 2 && sm->screens[2].update && sm->screens[2].tile)
                    sm->screens[2].update(sm->screens[2].tile);
                bsp_display_unlock();
            }
        }
    }
}

/* ── app_main ─────────────────────────────────────────────── */
void app_main(void)
{
    ESP_LOGI(TAG, "=== SmartWatch 5-Screen  v2.0 ===");

    bsp_display_cfg_t dcfg = { .lvgl_port_cfg = LVGL_PORT_INIT_CONFIG() };
    bsp_display_start_with_config(&dcfg);
    bsp_display_backlight_on();

    bsp_display_lock(pdMS_TO_TICKS(200));
    lv_obj_t *boot = lv_label_create(lv_screen_active());
    lv_obj_set_style_text_font(boot, &lv_font_montserrat_20, 0);
    lv_obj_set_style_text_color(boot, lv_color_hex(0xFFFFFF), 0);
    lv_label_set_long_mode(boot, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(boot, 400);
    lv_obj_set_style_text_align(boot, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(boot, LV_ALIGN_CENTER, 0, 0);
    lv_label_set_text(boot, "Initialising...");
    bsp_display_unlock();

    /* NVS init — must be called before any nvs_open() */
    esp_err_t nvs_ret = nvs_flash_init();
    if (nvs_ret == ESP_ERR_NVS_NO_FREE_PAGES ||
        nvs_ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        /* NVS partition was truncated — erase and reinit */
        nvs_flash_erase();
        nvs_flash_init();
    }

    /* SD card */
    int retry = 0;
    while (bsp_sdcard_mount() != ESP_OK) {
        ESP_LOGW(TAG, "SD mount attempt %d failed", ++retry);
        bsp_display_lock(pdMS_TO_TICKS(100));
        lv_label_set_text_fmt(boot, "SD card not found\nRetrying... (%d)", retry);
        bsp_display_unlock();
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
    struct stat st = {0};
    if (stat("/sdcard/rec", &st) != 0) mkdir("/sdcard/rec", 0775);
    if (stat("/sdcard/imu", &st) != 0) mkdir("/sdcard/imu", 0775);

    /* FIX 1: Read RTC before building UI */
    rtc_sync_to_system();

    /* Audio */
    if (bsp_extra_codec_init() != ESP_OK) {
        bsp_display_lock(pdMS_TO_TICKS(100));
        lv_label_set_text(boot, "Audio codec FAILED\nCheck hardware");
        lv_obj_set_style_text_color(boot, lv_color_hex(0xFF4444), 0);
        bsp_display_unlock();
        while (1) vTaskDelay(pdMS_TO_TICKS(1000));
    }
    bsp_extra_player_init();
    bsp_extra_codec_volume_set(100, NULL);

    /* Build UI */
    bsp_display_lock(pdMS_TO_TICKS(200));
    lv_obj_clean(lv_screen_active());
    app_ui_init();
    bsp_display_unlock();

    /* FIX 2: two update tasks */
    xTaskCreate(slow_update_task, "ui_slow", 4 * 1024, NULL, 3, NULL);
    xTaskCreate(fast_update_task, "ui_fast", 3 * 1024, NULL, 3, NULL);

    ESP_LOGI(TAG, "Ready.");
}
