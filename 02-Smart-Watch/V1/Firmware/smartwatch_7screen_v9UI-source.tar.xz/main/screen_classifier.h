/*
 * ================================================================
 *  screen_classifier.h  —  Screen 6: Motion Classifier
 * ================================================================
 *
 *  Real-time walking / sitting prediction using the trained
 *  Random Forest model (model_classifier.h + features.h).
 *
 *  Layout (480 × 480):
 *    Title "Motion Classifier"    — top centre
 *    Large result box (300×200)   — centre
 *      GREEN + "WALKING"  when walking is predicted
 *      RED   + "SITTING"  when sitting is predicted
 *      DARK  + "---"       when idle / not started
 *    [  START / STOP  ] button    — below result box
 *    Confidence / status label    — bottom
 *
 *  Rules:
 *    • START button begins continuous inference.
 *    • Every WINDOW_SIZE (50) new samples @ 100 Hz → one prediction.
 *    • Navigating away immediately stops inference.
 *    • Model runs on the same _imu_dev already initialised by
 *      screen_imu.h (shared I2C handle, never added twice).
 *
 *  Inference timing:
 *    esp_timer @ 10 ms → semaphore → inference task (Core 1)
 *    Ring buffer holds last WINDOW_SIZE samples.
 *    When buffer is full, features extracted + model run.
 *    Display updated only when prediction changes (reduces
 *    LVGL lock contention).
 *
 *  Screen index: 6
 * ================================================================
 */
#pragma once

#include <string.h>
#include <math.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "driver/i2c_master.h"
#include "lvgl.h"
#include "bsp/esp-bsp.h"
#include "theme.h"
#include "features.h"           /* compute_features(), WINDOW_SIZE, NUM_FEATURES */
#include "model_classifier.h"   /* mc_predict(), mc_label() */

/* Shared IMU device from screen_imu.h */
extern i2c_master_dev_handle_t _imu_dev;
extern bool                    _imu_ready;

/* Shared screen-manager active index */
extern screen_manager_t g_sm;

#define CLF_TAG           "Classifier"
#define CLF_SCREEN_IDX    6      /* 0=Home 1=Clock 2=IMU 3=Rec 4=Player 5=IMULog 6=CLF */

/* ── State ───────────────────────────────────────────────── */
typedef enum { CLF_STOPPED = 0, CLF_RUNNING } clf_state_t;
static volatile clf_state_t _clf_state    = CLF_STOPPED;
static volatile bool        _clf_req_stop = false;

/* Ring buffer — holds last WINDOW_SIZE raw samples */
static float  _clf_buf[WINDOW_SIZE][SENSOR_AXES];   /* [row][axis] */
static int    _clf_buf_head  = 0;     /* next write position (circular) */
static int    _clf_buf_count = 0;     /* total samples written so far   */

/* 100 Hz semaphore */
static SemaphoreHandle_t _clf_sem   = NULL;
static esp_timer_handle_t _clf_timer = NULL;

/* ── Widget handles ──────────────────────────────────────── */
static lv_obj_t *_clf_result_box  = NULL;   /* large colour box */
static lv_obj_t *_clf_result_lbl  = NULL;   /* WALKING / SITTING / --- */
static lv_obj_t *_clf_btn         = NULL;
static lv_obj_t *_clf_btn_lbl     = NULL;
static lv_obj_t *_clf_status_lbl  = NULL;

/* ── 100 Hz timer callback — only signals the task ───────── */
static void _clf_timer_cb(void *arg)
{
    BaseType_t woken = pdFALSE;
    xSemaphoreGiveFromISR(_clf_sem, &woken);
    portYIELD_FROM_ISR(woken);
}

/* ── Read one sample from shared QMI8658 I2C device ──────── */
static void _clf_read_sample(float *acc_x, float *acc_y, float *acc_z,
                              float *gyr_x, float *gyr_y, float *gyr_z)
{
    uint8_t raw[12] = {0};
    uint8_t reg_ax  = 0x35;   /* AX_L — 6 bytes accel */
    uint8_t reg_gx  = 0x3B;   /* GX_L — 6 bytes gyro  */

    float acc_scale = 4.0f   / 32768.0f;
    float gyr_scale = 512.0f / 32768.0f;

    if (i2c_master_transmit_receive(_imu_dev, &reg_ax, 1,
                                    raw, 6, pdMS_TO_TICKS(5)) == ESP_OK) {
        *acc_x = (int16_t)((raw[1]<<8)|raw[0]) * acc_scale;
        *acc_y = (int16_t)((raw[3]<<8)|raw[2]) * acc_scale;
        *acc_z = (int16_t)((raw[5]<<8)|raw[4]) * acc_scale;
    } else {
        *acc_x = *acc_y = *acc_z = 0.0f;
    }

    if (i2c_master_transmit_receive(_imu_dev, &reg_gx, 1,
                                    raw, 6, pdMS_TO_TICKS(5)) == ESP_OK) {
        *gyr_x = (int16_t)((raw[1]<<8)|raw[0]) * gyr_scale;
        *gyr_y = (int16_t)((raw[3]<<8)|raw[2]) * gyr_scale;
        *gyr_z = (int16_t)((raw[5]<<8)|raw[4]) * gyr_scale;
    } else {
        *gyr_x = *gyr_y = *gyr_z = 0.0f;
    }
}

/* ── Update result box colour and text (call with display lock) */
static void _clf_update_display(int label_idx)
{
    if (!_clf_result_box || !lv_obj_is_valid(_clf_result_box)) return;
    if (!_clf_result_lbl || !lv_obj_is_valid(_clf_result_lbl)) return;

    if (label_idx < 0) {
        /* Idle / not started */
        lv_obj_set_style_bg_color(_clf_result_box,
            lv_color_hex(C_BG_PANEL), 0);
        lv_label_set_text(_clf_result_lbl, "---");
        lv_obj_set_style_text_color(_clf_result_lbl,
            lv_color_hex(C_TEXT_DIM), 0);
    } else if (label_idx == LABEL_WALKING) {
        /* Walking → GREEN box */
        lv_obj_set_style_bg_color(_clf_result_box,
            lv_color_hex(0x1A6B2E), 0);   /* dark green */
        lv_label_set_text(_clf_result_lbl, "WALKING");
        lv_obj_set_style_text_color(_clf_result_lbl,
            lv_color_hex(0x88FF88), 0);
    } else {
        /* Sitting → RED box */
        lv_obj_set_style_bg_color(_clf_result_box,
            lv_color_hex(0x6B1A1A), 0);   /* dark red */
        lv_label_set_text(_clf_result_lbl, "SITTING");
        lv_obj_set_style_text_color(_clf_result_lbl,
            lv_color_hex(0xFF8888), 0);
    }
}

/* ── Inference task — runs on Core 1 ─────────────────────── */
static void _clf_task(void *pv)
{
    /* Reset ring buffer */
    _clf_buf_head  = 0;
    _clf_buf_count = 0;

    /* Start 100 Hz timer */
    esp_timer_start_periodic(_clf_timer, 10000);   /* 10 000 µs = 10 ms */

    int last_label = -2;   /* force first display update */

    while (!_clf_req_stop) {
        /* Wait for 10 ms tick */
        if (xSemaphoreTake(_clf_sem, pdMS_TO_TICKS(50)) != pdTRUE) {
            /* Timeout — check if screen was left */
            if (g_sm.active_idx != CLF_SCREEN_IDX)
                _clf_req_stop = true;
            continue;
        }

        /* Read one IMU sample */
        float ax, ay, az, gx, gy, gz;
        _clf_read_sample(&ax, &ay, &az, &gx, &gy, &gz);

        /* Store in circular ring buffer */
        _clf_buf[_clf_buf_head][0] = ax;
        _clf_buf[_clf_buf_head][1] = ay;
        _clf_buf[_clf_buf_head][2] = az;
        _clf_buf[_clf_buf_head][3] = gx;
        _clf_buf[_clf_buf_head][4] = gy;
        _clf_buf[_clf_buf_head][5] = gz;
        _clf_buf_head  = (_clf_buf_head + 1) % WINDOW_SIZE;
        _clf_buf_count++;

        /* Need WINDOW_SIZE samples before first prediction */
        if (_clf_buf_count < WINDOW_SIZE) {
            if (g_sm.active_idx != CLF_SCREEN_IDX)
                _clf_req_stop = true;
            continue;
        }

        /* Build ordered window from ring buffer (oldest → newest) */
        float window[WINDOW_SIZE][SENSOR_AXES];
        for (int i = 0; i < WINDOW_SIZE; i++) {
            /* Index of the i-th oldest sample in the circular buffer */
            int src = (_clf_buf_head + i) % WINDOW_SIZE;
            for (int ax2 = 0; ax2 < SENSOR_AXES; ax2++)
                window[i][ax2] = _clf_buf[src][ax2];
        }

        /* Compute 84 features */
        float feats[NUM_FEATURES];
        compute_features(window, feats);

        /* Run model */
        int pred = mc_predict(feats);

        /* Update display only when prediction changes */
        if (pred != last_label) {
            last_label = pred;
            if (bsp_display_lock(pdMS_TO_TICKS(30))) {
                _clf_update_display(pred);
                if (_clf_status_lbl && lv_obj_is_valid(_clf_status_lbl)) {
                    char msg[48];
                    snprintf(msg, sizeof(msg), "Predicted: %s",
                             mc_label(pred));
                    lv_label_set_text(_clf_status_lbl, msg);
                    lv_obj_set_style_text_color(_clf_status_lbl,
                        lv_color_hex(C_ACCENT), 0);
                }
                bsp_display_unlock();
            }
            ESP_LOGI(CLF_TAG, "Prediction: %s", mc_label(pred));
        }

        /* Auto-stop if screen navigated away */
        if (g_sm.active_idx != CLF_SCREEN_IDX)
            _clf_req_stop = true;
    }

    /* Stop timer */
    esp_timer_stop(_clf_timer);

    bool away = (g_sm.active_idx != CLF_SCREEN_IDX);

    /* Restore UI */
    if (bsp_display_lock(pdMS_TO_TICKS(200))) {
        if (_clf_btn && lv_obj_is_valid(_clf_btn)) {
            lv_obj_set_style_bg_color(_clf_btn,
                lv_color_hex(C_GREEN_BTN),
                LV_PART_MAIN | LV_STATE_DEFAULT);
            lv_label_set_text(_clf_btn_lbl, LV_SYMBOL_PLAY "  START");
        }
        _clf_update_display(-1);   /* reset box to idle */
        if (_clf_status_lbl && lv_obj_is_valid(_clf_status_lbl)) {
            if (away) {
                lv_label_set_text(_clf_status_lbl,
                    "Stopped: screen was left");
                lv_obj_set_style_text_color(_clf_status_lbl,
                    lv_color_hex(0xFF8844), 0);
            } else {
                lv_label_set_text(_clf_status_lbl,
                    "Press START to classify");
                lv_obj_set_style_text_color(_clf_status_lbl,
                    lv_color_hex(C_TEXT_DIM), 0);
            }
        }
        bsp_display_unlock();
    }

    _clf_req_stop = false;
    _clf_state    = CLF_STOPPED;
    vTaskDelete(NULL);
}

/* ── START / STOP button callback ────────────────────────── */
static void _clf_btn_cb(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;

    if (_clf_state == CLF_STOPPED) {
        /* Check IMU is ready */
        if (!_imu_ready) {
            lv_label_set_text(_clf_status_lbl, "IMU not ready!");
            lv_obj_set_style_text_color(_clf_status_lbl,
                lv_color_hex(0xFF4444), 0);
            return;
        }

        _clf_req_stop = false;
        _clf_state    = CLF_RUNNING;

        lv_obj_set_style_bg_color(_clf_btn, lv_color_hex(C_RED_BTN),
                                  LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_label_set_text(_clf_btn_lbl, LV_SYMBOL_STOP "  STOP");
        _clf_update_display(-1);
        lv_label_set_text(_clf_status_lbl, "Collecting samples...");
        lv_obj_set_style_text_color(_clf_status_lbl,
            lv_color_hex(C_ACCENT), 0);

        xTaskCreatePinnedToCore(_clf_task, "clf_task",
                                6 * 1024, NULL, 5, NULL, 1);
    } else {
        _clf_req_stop = true;
        lv_label_set_text(_clf_status_lbl, "Stopping...");
        lv_obj_set_style_text_color(_clf_status_lbl,
            lv_color_hex(0xFFDD55), 0);
    }
}

/* ── Screen create / update ──────────────────────────────── */
lv_obj_t *screen_classifier_create(lv_obj_t *tile)
{
    /* Create semaphore and timer once */
    if (!_clf_sem)
        _clf_sem = xSemaphoreCreateBinary();

    if (!_clf_timer) {
        esp_timer_create_args_t ta = {
            .callback        = _clf_timer_cb,
            .arg             = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name            = "clf_100hz",
        };
        esp_timer_create(&ta, &_clf_timer);
    }

    /* ── Background ── */
    lv_obj_set_style_bg_color(tile, lv_color_hex(C_BG_MID), 0);
    lv_obj_set_style_bg_opa(tile, LV_OPA_COVER, 0);
    lv_obj_clear_flag(tile, LV_OBJ_FLAG_SCROLLABLE);

    /* ── Title ── */
    lv_obj_t *title = lv_label_create(tile);
    lv_label_set_text(title, "Motion Classifier");
    lv_obj_set_style_text_font(title, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(title, lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 22);

    /* Accent line */
    lv_obj_t *line = lv_obj_create(tile);
    lv_obj_set_size(line, 200, 3);
    lv_obj_align(line, LV_ALIGN_TOP_MID, 0, 58);
    lv_obj_set_style_bg_color(line, lv_color_hex(C_ACCENT), 0);
    lv_obj_set_style_border_width(line, 0, 0);
    lv_obj_set_style_radius(line, 2, 0);
    lv_obj_clear_flag(line, LV_OBJ_FLAG_SCROLLABLE);

    /*
     *  Layout  (all in centre safe zone  120–360 px)
     *  ────────────────────────────────────────────
     *  y= 75   Result box   300 × 220  centred
     *  y=315   [  START / STOP  ]  button  220×72
     *  y=415   status label
     */

    /* ── Result box (large centred card) ── */
    _clf_result_box = lv_obj_create(tile);
    lv_obj_set_size(_clf_result_box, 300, 220);
    lv_obj_align(_clf_result_box, LV_ALIGN_TOP_MID, 0, 75);
    lv_obj_set_style_bg_color(_clf_result_box,
        lv_color_hex(C_BG_PANEL), 0);
    lv_obj_set_style_bg_opa(_clf_result_box, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(_clf_result_box, 20, 0);
    lv_obj_set_style_border_color(_clf_result_box,
        lv_color_hex(C_ACCENT_DARK), 0);
    lv_obj_set_style_border_width(_clf_result_box, 2, 0);
    lv_obj_clear_flag(_clf_result_box, LV_OBJ_FLAG_SCROLLABLE);

    /* Result text inside box */
    _clf_result_lbl = lv_label_create(_clf_result_box);
    lv_label_set_text(_clf_result_lbl, "---");
    lv_obj_set_style_text_font(_clf_result_lbl, &lv_font_montserrat_48, 0);
    lv_obj_set_style_text_color(_clf_result_lbl,
        lv_color_hex(C_TEXT_DIM), 0);
    lv_obj_center(_clf_result_lbl);

    /* ── START / STOP button ── */
    _clf_btn = lv_btn_create(tile);
    lv_obj_set_size(_clf_btn, BTN_W_FULL, BTN_H);
    lv_obj_align(_clf_btn, LV_ALIGN_TOP_MID, 0, 315);
    lv_obj_set_style_radius(_clf_btn, BTN_H / 2, LV_PART_MAIN);
    lv_obj_set_style_bg_color(_clf_btn, lv_color_hex(C_GREEN_BTN),
                              LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(_clf_btn, lv_color_hex(C_GREEN_BTN_PR),
                              LV_PART_MAIN | LV_STATE_PRESSED);
    lv_obj_set_style_shadow_width(_clf_btn, 16, LV_PART_MAIN);
    lv_obj_set_style_shadow_color(_clf_btn,
        lv_color_hex(C_GREEN_BTN), LV_PART_MAIN);
    lv_obj_add_event_cb(_clf_btn, _clf_btn_cb, LV_EVENT_CLICKED, NULL);

    _clf_btn_lbl = lv_label_create(_clf_btn);
    lv_label_set_text(_clf_btn_lbl, LV_SYMBOL_PLAY "  START");
    lv_obj_set_style_text_font(_clf_btn_lbl, &lv_font_montserrat_20, 0);
    lv_obj_set_style_text_color(_clf_btn_lbl,
        lv_color_hex(C_TEXT_PRIMARY), 0);
    lv_obj_center(_clf_btn_lbl);

    /* ── Status label ── */
    _clf_status_lbl = lv_label_create(tile);
    lv_label_set_long_mode(_clf_status_lbl, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(_clf_status_lbl, DISP_W - 80);
    lv_label_set_text(_clf_status_lbl, "Press START to classify");
    lv_obj_set_style_text_font(_clf_status_lbl, &lv_font_montserrat_14, 0);
    lv_obj_set_style_text_color(_clf_status_lbl,
        lv_color_hex(C_TEXT_DIM), 0);
    lv_obj_set_style_text_align(_clf_status_lbl, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(_clf_status_lbl, LV_ALIGN_BOTTOM_MID, 0, -20);

    return tile;
}

void screen_classifier_update(lv_obj_t *tile)
{
    (void)tile;
    /* All updates driven by inference task + button callback */
}
