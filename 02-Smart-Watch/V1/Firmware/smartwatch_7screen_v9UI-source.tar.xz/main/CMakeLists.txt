idf_component_register(
    SRCS
        "main.c"
    INCLUDE_DIRS
        "."
    REQUIRES
        esp_timer
        freertos
        nvs_flash
        driver
        fatfs
        esp_lcd
        bsp_extra
        ## Managed components (BSP, LVGL, audio) are resolved via
        ## idf_component.yml — their include paths are added automatically.
)
