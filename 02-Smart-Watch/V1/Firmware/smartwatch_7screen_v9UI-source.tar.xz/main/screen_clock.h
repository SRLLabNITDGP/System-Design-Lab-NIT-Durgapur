/*
 * ================================================================
 *  screen_clock.h — Screen 1: RTC Real Clock
 *  Uses PCF85063 via BSP  (bsp/esp-bsp.h)
 * ================================================================
 */
#pragma once
#include <time.h>
#include "lvgl.h"
#include "theme.h"

/* ── widget handles (file-scope statics) ───────────────── */
static lv_obj_t *_clk_lbl_hhmm = NULL;
static lv_obj_t *_clk_lbl_sec  = NULL;
static lv_obj_t *_clk_lbl_date = NULL;
static int       _clk_last_sec = -1;

lv_obj_t *screen_clock_create(lv_obj_t *tile)
{
    lv_obj_set_style_bg_color(tile, lv_color_hex(C_BG_DARK), 0);
    lv_obj_set_style_bg_opa(tile, LV_OPA_COVER, 0);
    lv_obj_clear_flag(tile, LV_OBJ_FLAG_SCROLLABLE);

    /* Tag */
    lv_obj_t *tag = lv_label_create(tile);
    lv_label_set_text(tag, "CLOCK");
    lv_obj_set_style_text_font(tag, &lv_font_montserrat_12, 0);
    lv_obj_set_style_text_color(tag, lv_color_hex(C_ACCENT_DARK), 0);
    lv_obj_align(tag, LV_ALIGN_TOP_MID, 0, 24);

    /* Circular clock ring — centred, shifted slightly up */
    lv_obj_t *ring = lv_obj_create(tile);
    lv_obj_set_size(ring, 300, 300);
    lv_obj_align(ring, LV_ALIGN_CENTER, 0, -25);
    lv_obj_set_style_radius(ring, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(ring, lv_color_hex(0x0B0B2A), 0);
    lv_obj_set_style_border_color(ring, lv_color_hex(C_ACCENT_DARK), 0);
    lv_obj_set_style_border_width(ring, 2, 0);
    lv_obj_set_style_bg_opa(ring, LV_OPA_COVER, 0);
    lv_obj_clear_flag(ring, LV_OBJ_FLAG_SCROLLABLE);

    /* HH:MM — large, inside ring */
    _clk_lbl_hhmm = lv_label_create(ring);
    lv_label_set_text(_clk_lbl_hhmm, "00:00");
    lv_obj_set_style_text_font(_clk_lbl_hhmm, &lv_font_montserrat_48, 0);
    lv_obj_set_style_text_color(_clk_lbl_hhmm, lv_color_hex(C_TEXT_BRIGHT), 0);
    lv_obj_align(_clk_lbl_hhmm, LV_ALIGN_CENTER, 0, -20);

    /* :SS — smaller, below HH:MM */
    _clk_lbl_sec = lv_label_create(ring);
    lv_label_set_text(_clk_lbl_sec, ":00");
    lv_obj_set_style_text_font(_clk_lbl_sec, &lv_font_montserrat_28, 0);
    lv_obj_set_style_text_color(_clk_lbl_sec, lv_color_hex(C_ACCENT), 0);
    lv_obj_align(_clk_lbl_sec, LV_ALIGN_CENTER, 60, 28);

    /* Date — below ring, centred */
    _clk_lbl_date = lv_label_create(tile);
    lv_label_set_text(_clk_lbl_date, "-- / -- / ----");
    lv_obj_set_style_text_font(_clk_lbl_date, &lv_font_montserrat_16, 0);
    lv_obj_set_style_text_color(_clk_lbl_date, lv_color_hex(C_TEXT_DIM), 0);
    lv_obj_align(_clk_lbl_date, LV_ALIGN_CENTER, 0, 140);

    _clk_last_sec = -1;
    return tile;
}

void screen_clock_update(lv_obj_t *tile)
{
    (void)tile;
    if (!_clk_lbl_hhmm) return;

    /* Read system time (BSP sets it via SNTP or RTC) */
    time_t now;
    struct tm t;
    time(&now);
    localtime_r(&now, &t);

    if (t.tm_sec == _clk_last_sec) return;
    _clk_last_sec = t.tm_sec;

    char hhmm[8];
    snprintf(hhmm, sizeof(hhmm), "%02d:%02d", t.tm_hour, t.tm_min);
    lv_label_set_text(_clk_lbl_hhmm, hhmm);

    char sec[5];
    snprintf(sec, sizeof(sec), ":%02d", t.tm_sec);
    lv_label_set_text(_clk_lbl_sec, sec);

    char date[24];
    snprintf(date, sizeof(date), "%02d / %02d / %04d",
             t.tm_mday, t.tm_mon + 1, t.tm_year + 1900);
    lv_label_set_text(_clk_lbl_date, date);
}
