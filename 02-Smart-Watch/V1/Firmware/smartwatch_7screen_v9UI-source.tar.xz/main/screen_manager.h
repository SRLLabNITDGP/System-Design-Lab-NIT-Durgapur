/*
 * ================================================================
 *  screen_manager.h — Scalable Screen Registry  (ESP-IDF version)
 * ================================================================
 *
 *  HOW TO ADD A NEW SCREEN (3 steps only):
 *  1. Create screen_xyz.h  with  screen_xyz_create() + screen_xyz_update()
 *  2. #include "screen_xyz.h" in main.c
 *  3. screen_manager_register("XYZ", screen_xyz_create, screen_xyz_update);
 *     inside app_ui_init(), BEFORE screen_manager_build().
 *
 *  NAVIGATION  — Two narrow edge panels (left 25 %, right 25 %)
 *  ─────────────────────────────────────────────────────────────
 *    Left  edge (0–119 px)   TAP or RIGHT-swipe → previous screen
 *    Right edge (360–479 px) TAP or LEFT-swipe  → next screen
 *    Centre (120–359 px)     COMPLETELY FREE — buttons click,
 *                            lists scroll, no overlay at all.
 *
 *  The old full-screen transparent overlay has been replaced with
 *  two narrow panels that sit only on the left and right edges.
 *  This means:
 *    • REC / STOP and all other centre buttons work normally.
 *    • The file-list in the Player screen scrolls normally.
 *    • You can also swipe FROM the edge to navigate (right-swipe
 *      on left panel = prev, left-swipe on right panel = next).
 *
 *  SCREEN SIZE: 480 × 480  (ESP32-S3-Touch-AMOLED-2.06)
 *
 * ================================================================
 */

#pragma once

#include "lvgl.h"

/* ── callback signatures ─────────────────────────────────── */
typedef lv_obj_t *(*sm_create_fn_t)(lv_obj_t *tile);
typedef void      (*sm_update_fn_t)(lv_obj_t *tile);

/* ── registry limits ──────────────────────────────────────── */
#define SM_MAX_SCREENS  16

/* ── navigation zone as fraction of screen width ─────────── */
#define SM_ZONE_FRACTION  0.25f

/* ── opaque handle (one global instance) ──────────────────── */
typedef struct {
    const char      *label;
    sm_create_fn_t   create;
    sm_update_fn_t   update;
    lv_obj_t        *tile;
} sm_entry_t;

typedef struct {
    sm_entry_t   screens[SM_MAX_SCREENS];
    int          count;
    lv_obj_t    *tileview;
    int          active_idx;
    int          scr_w;
} screen_manager_t;

/* ── single global instance declared in main.c ──────────── */
extern screen_manager_t g_sm;

/* ─────────────────────────────────────────────────────────
   screen_manager_register()
   Call once per screen, IN ORDER, before screen_manager_build().
   ───────────────────────────────────────────────────────── */
static inline void screen_manager_register(const char *label,
                                           sm_create_fn_t create,
                                           sm_update_fn_t update)
{
    if (g_sm.count >= SM_MAX_SCREENS) return;
    g_sm.screens[g_sm.count].label  = label;
    g_sm.screens[g_sm.count].create = create;
    g_sm.screens[g_sm.count].update = update;
    g_sm.screens[g_sm.count].tile   = NULL;
    g_sm.count++;
}

/* ─────────────────────────────────────────────────────────
   _sm_go_to() — internal, navigate with explicit direction
   direction: +1 = forward,  -1 = backward
   ───────────────────────────────────────────────────────── */
static inline void _sm_go_to(int target, int direction)
{
    screen_manager_t *sm = &g_sm;
    if (sm->count < 2 || !sm->tileview) return;
    if (target == sm->active_idx) return;

    bool need_wrap = false;
    if (direction == +1 && target < sm->active_idx) need_wrap = true;
    if (direction == -1 && target > sm->active_idx) need_wrap = true;

    if (!need_wrap) {
        sm->active_idx = target;
        lv_tileview_set_tile(sm->tileview, sm->screens[sm->active_idx].tile, LV_ANIM_ON);
    } else {
        lv_coord_t w = (lv_coord_t)lv_obj_get_width(sm->tileview);
        if (direction == +1)
            lv_obj_scroll_to_x(sm->tileview, (lv_coord_t)(sm->count) * w, LV_ANIM_OFF);
        else
            lv_obj_scroll_to_x(sm->tileview, (lv_coord_t)(-1) * w, LV_ANIM_OFF);
        lv_timer_handler();
        sm->active_idx = target;
        lv_tileview_set_tile(sm->tileview, sm->screens[sm->active_idx].tile, LV_ANIM_ON);
    }
}

/* ─────────────────────────────────────────────────────────
   Public navigation helpers
   ───────────────────────────────────────────────────────── */
static inline void screen_manager_next(void)
{
    int t = (g_sm.active_idx + 1) % g_sm.count;
    _sm_go_to(t, +1);
}

static inline void screen_manager_prev(void)
{
    int t = (g_sm.active_idx - 1 + g_sm.count) % g_sm.count;
    _sm_go_to(t, -1);
}

/* ─────────────────────────────────────────────────────────
   Edge-panel callbacks
   Each panel covers only its navigation strip (left or right
   25 % of the screen).  The centre 50 % is completely
   unobstructed — buttons click and lists scroll freely.

   Both TAP and SWIPE on an edge panel trigger navigation:
     Left  panel  tap  OR swipe-right → prev screen
     Right panel  tap  OR swipe-left  → next screen

   Swipe detection: if the touch moved more than SWIPE_THRESH
   pixels horizontally during the gesture, treat it as a swipe
   regardless of direction within the panel.
   ───────────────────────────────────────────────────────── */

#define SM_SWIPE_THRESH  20   /* px of horizontal movement = swipe */

/* Stores the press-point so we can measure swipe distance */
static lv_point_t _sm_press_pt_l = {0, 0};
static lv_point_t _sm_press_pt_r = {0, 0};

/* Left edge panel ─────────────────────────────────────── */
static void _sm_left_panel_cb(lv_event_t *e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_indev_t     *indev = lv_indev_get_act();
    lv_point_t      pt;
    lv_indev_get_point(indev, &pt);

    if (code == LV_EVENT_PRESSED) {
        _sm_press_pt_l = pt;                   /* record touch-down */
    } else if (code == LV_EVENT_RELEASED) {
        int32_t dx = pt.x - _sm_press_pt_l.x; /* positive = swiped right */
        /* navigate prev on: tap (small movement) OR rightward swipe */
        if (dx > -SM_SWIPE_THRESH) {           /* not a leftward drag */
            screen_manager_prev();
        }
    }
}

/* Right edge panel ────────────────────────────────────── */
static void _sm_right_panel_cb(lv_event_t *e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_indev_t     *indev = lv_indev_get_act();
    lv_point_t      pt;
    lv_indev_get_point(indev, &pt);

    if (code == LV_EVENT_PRESSED) {
        _sm_press_pt_r = pt;
    } else if (code == LV_EVENT_RELEASED) {
        int32_t dx = pt.x - _sm_press_pt_r.x; /* negative = swiped left */
        /* navigate next on: tap (small movement) OR leftward swipe */
        if (dx < SM_SWIPE_THRESH) {            /* not a rightward drag */
            screen_manager_next();
        }
    }
}

/* ─────────────────────────────────────────────────────────
   screen_manager_build()
   Call ONCE after all screens are registered.
   Must be called with bsp_display_lock held or from LVGL task.
   ───────────────────────────────────────────────────────── */
static inline void screen_manager_build(void)
{
    screen_manager_t *sm = &g_sm;
    sm->scr_w = lv_display_get_horizontal_resolution(lv_display_get_default());
    int scr_h = lv_display_get_vertical_resolution(lv_display_get_default());

    /* nav zone width in pixels */
    int zone_w = (int)(sm->scr_w * SM_ZONE_FRACTION);

    /* tileview ─────────────────────────────────────────── */
    sm->tileview = lv_tileview_create(lv_scr_act());
    lv_obj_set_size(sm->tileview, LV_PCT(100), LV_PCT(100));
    lv_obj_align(sm->tileview, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_set_style_bg_color(sm->tileview, lv_color_black(), 0);
    lv_obj_set_scrollbar_mode(sm->tileview, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scroll_snap_x(sm->tileview, LV_SCROLL_SNAP_CENTER);
    /* disable manual swipe — edge panels handle navigation */
    lv_obj_clear_flag(sm->tileview, LV_OBJ_FLAG_SCROLLABLE);

    for (int i = 0; i < sm->count; i++) {
        lv_obj_t *tile = lv_tileview_add_tile(sm->tileview, i, 0, LV_DIR_HOR);
        lv_obj_set_style_bg_color(tile, lv_color_black(), 0);
        lv_obj_set_style_bg_opa(tile, LV_OPA_COVER, 0);
        lv_obj_clear_flag(tile, LV_OBJ_FLAG_SCROLLABLE);
        sm->screens[i].tile = tile;
        sm->screens[i].create(tile);
    }

    /* ── Left edge navigation panel (0 … zone_w px) ─────
     * Transparent strip on the left edge only.
     * Does NOT cover the centre — buttons and lists there
     * are completely unaffected.
     * ─────────────────────────────────────────────────── */
    lv_obj_t *left_panel = lv_obj_create(lv_scr_act());
    lv_obj_set_size(left_panel, zone_w, scr_h);
    lv_obj_set_pos(left_panel, 0, 0);
    lv_obj_set_style_bg_opa(left_panel, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(left_panel, 0, 0);
    lv_obj_set_style_pad_all(left_panel, 0, 0);
    lv_obj_clear_flag(left_panel, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(left_panel, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_move_foreground(left_panel);
    lv_obj_add_event_cb(left_panel, _sm_left_panel_cb,  LV_EVENT_PRESSED,  NULL);
    lv_obj_add_event_cb(left_panel, _sm_left_panel_cb,  LV_EVENT_RELEASED, NULL);

    /* ── Right edge navigation panel (scr_w-zone_w … scr_w) */
    lv_obj_t *right_panel = lv_obj_create(lv_scr_act());
    lv_obj_set_size(right_panel, zone_w, scr_h);
    lv_obj_set_pos(right_panel, sm->scr_w - zone_w, 0);
    lv_obj_set_style_bg_opa(right_panel, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(right_panel, 0, 0);
    lv_obj_set_style_pad_all(right_panel, 0, 0);
    lv_obj_clear_flag(right_panel, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(right_panel, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_move_foreground(right_panel);
    lv_obj_add_event_cb(right_panel, _sm_right_panel_cb, LV_EVENT_PRESSED,  NULL);
    lv_obj_add_event_cb(right_panel, _sm_right_panel_cb, LV_EVENT_RELEASED, NULL);
}

/* ─────────────────────────────────────────────────────────
   screen_manager_tick()
   Call periodically (e.g. every 1 s) to refresh active screen.
   ───────────────────────────────────────────────────────── */
static inline void screen_manager_tick(void)
{
    screen_manager_t *sm = &g_sm;
    if (sm->count == 0 || !sm->tileview) return;

    lv_obj_t *active = lv_tileview_get_tile_act(sm->tileview);
    for (int i = 0; i < sm->count; i++) {
        if (sm->screens[i].tile == active) {
            sm->active_idx = i;
            if (sm->screens[i].update)
                sm->screens[i].update(sm->screens[i].tile);
            return;
        }
    }
}
