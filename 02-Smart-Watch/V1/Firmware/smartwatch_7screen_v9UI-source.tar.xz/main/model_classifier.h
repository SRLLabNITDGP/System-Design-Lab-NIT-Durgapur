/*
 * model.h — Activity Classifier (Walking vs Sitting)
 * Auto-generated from sklearn RandomForest — PURE PLAIN C
 * No C++, no namespace, no class, no <cstdarg>.
 * Compiles directly with ESP-IDF xtensa-esp32s3-elf-gcc.
 *
 * Classes  : 0=sitting  /  1=walking
 * Features : 84  (computed by features.h compute_features())
 * Trees    : 15   Max depth: 8
 * Accuracy : 99.9% on test set
 *
 * Drop into ESP-IDF main/ folder and use like this:
 *   #include "features.h"
 *   #include "model.h"
 *   float feats[NUM_FEATURES];
 *   compute_features(window, feats);
 *   int label     = mc_predict(feats);   // 0=sitting  1=walking
 *   const char *s = mc_label(label);     // "sitting" or "walking"
 */
#ifndef MODEL_H
#define MODEL_H

#include <stdint.h>

/**
 * mc_predict() - run the Random Forest on a 84-element feature vector.
 * @param x   float array of length 84 produced by compute_features()
 * @return    0 = sitting,  1 = walking
 */
static inline int mc_predict(float *x)
{
    uint8_t votes[2] = {0};

    /* tree #1 */
    if (x[57] <= 79588.36328125f) {
        if (x[30] <= 0.06499999947845936f) {
            if (x[65] <= -14.46180009841919f) {
                if (x[45] <= 27.87932777404785f) {
                    votes[1] += 1;
                } else {
                    votes[0] += 1;
                }
            } else {
                if (x[16] <= -0.004999999888241291f) {
                    votes[0] += 1;
                } else {
                    votes[0] += 1;
                }
            }
        } else {
            if (x[69] <= 69.20999908447266f) {
                votes[0] += 1;
            } else {
                votes[1] += 1;
            }
        }
    } else {
        if (x[36] <= 8.5f) {
            if (x[3] <= 0.06499999947845936f) {
                votes[1] += 1;
            } else {
                if (x[81] <= 0.1945175603032112f) {
                    votes[1] += 1;
                } else {
                    votes[0] += 1;
                }
            }
        } else {
            votes[0] += 1;
        }
    }

    /* tree #2 */
    if (x[58] <= 41.38995170593262f) {
        if (x[42] <= 87.05499649047852f) {
            votes[0] += 1;
        } else {
            if (x[82] <= 0.3081664592027664f) {
                if (x[50] <= 7.5f) {
                    votes[0] += 1;
                } else {
                    votes[0] += 1;
                }
            } else {
                votes[1] += 1;
            }
        }
    } else {
        if (x[51] <= 0.11263979971408844f) {
            votes[0] += 1;
        } else {
            if (x[69] <= 81.92000198364258f) {
                if (x[57] <= 134041.5078125f) {
                    votes[0] += 1;
                } else {
                    if (x[18] <= 0.004050000105053186f) {
                        votes[1] += 1;
                    } else {
                        votes[1] += 1;
                    }
                }
            } else {
                votes[1] += 1;
            }
        }
    }

    /* tree #3 */
    if (x[58] <= 39.896095275878906f) {
        if (x[41] <= -23.024999618530273f) {
            if (x[69] <= 94.43500137329102f) {
                if (x[5] <= 0.01674999948590994f) {
                    votes[0] += 1;
                } else {
                    votes[0] += 1;
                }
            } else {
                votes[1] += 1;
            }
        } else {
            if (x[30] <= 0.004999999888241291f) {
                votes[0] += 1;
            } else {
                votes[0] += 1;
            }
        }
    } else {
        if (x[2] <= -0.004999999888241291f) {
            if (x[0] <= 0.02039999980479479f) {
                votes[1] += 1;
            } else {
                votes[1] += 1;
            }
        } else {
            if (x[61] <= 14.250543594360352f) {
                votes[0] += 1;
            } else {
                votes[0] += 1;
            }
        }
    }

    /* tree #4 */
    if (x[70] <= 25976.1123046875f) {
        if (x[2] <= -0.014999999664723873f) {
            if (x[44] <= 31182.8408203125f) {
                votes[0] += 1;
            } else {
                votes[1] += 1;
            }
        } else {
            if (x[28] <= -0.1550000011920929f) {
                if (x[56] <= 53.005001068115234f) {
                    votes[0] += 1;
                } else {
                    votes[0] += 1;
                }
            } else {
                votes[0] += 1;
            }
        }
    } else {
        if (x[63] <= 4.5f) {
            if (x[27] <= 0.006605655187740922f) {
                votes[0] += 1;
            } else {
                if (x[0] <= 0.022499999962747097f) {
                    votes[1] += 1;
                } else {
                    if (x[39] <= 31.729900360107422f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            }
        } else {
            if (x[58] <= 50.90977668762207f) {
                if (x[6] <= 0.03792005404829979f) {
                    if (x[42] <= 27.079999923706055f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                } else {
                    if (x[6] <= 0.04071780666708946f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            } else {
                votes[1] += 1;
            }
        }
    }

    /* tree #5 */
    if (x[64] <= 0.3779499679803848f) {
        if (x[28] <= -0.14500000327825546f) {
            if (x[63] <= 7.5f) {
                votes[1] += 1;
            } else {
                if (x[54] <= -108.1500015258789f) {
                    votes[0] += 1;
                } else {
                    votes[0] += 1;
                }
            }
        } else {
            if (x[48] <= 5.441237688064575f) {
                if (x[0] <= -0.02539999969303608f) {
                    votes[1] += 1;
                } else {
                    votes[0] += 1;
                }
            } else {
                if (x[9] <= 0.004279074724763632f) {
                    votes[0] += 1;
                } else {
                    votes[0] += 1;
                }
            }
        }
    } else {
        if (x[31] <= 0.7941999733448029f) {
            if (x[9] <= 0.010270868893712759f) {
                if (x[54] <= -85.18000030517578f) {
                    votes[1] += 1;
                } else {
                    votes[0] += 1;
                }
            } else {
                votes[0] += 1;
            }
        } else {
            votes[1] += 1;
        }
    }

    /* tree #6 */
    if (x[79] <= 22.435365676879883f) {
        if (x[2] <= -0.03499999921768904f) {
            votes[1] += 1;
        } else {
            if (x[46] <= 38.14999961853027f) {
                votes[0] += 1;
            } else {
                votes[0] += 1;
            }
        }
    } else {
        if (x[57] <= 64442.30859375f) {
            if (x[44] <= 151231.734375f) {
                votes[0] += 1;
            } else {
                votes[0] += 1;
            }
        } else {
            if (x[37] <= 6.5f) {
                if (x[78] <= 0.011814711149781942f) {
                    if (x[41] <= -38.665000915527344f) {
                        votes[1] += 1;
                    } else {
                        votes[1] += 1;
                    }
                } else {
                    votes[1] += 1;
                }
            } else {
                if (x[74] <= 13.118753910064697f) {
                    votes[0] += 1;
                } else {
                    votes[1] += 1;
                }
            }
        }
    }

    /* tree #7 */
    if (x[64] <= 0.4409525990486145f) {
        if (x[58] <= 41.38995170593262f) {
            if (x[28] <= -0.16499999910593033f) {
                if (x[65] <= 4.854300260543823f) {
                    votes[1] += 1;
                } else {
                    votes[0] += 1;
                }
            } else {
                if (x[59] <= 11.422500133514404f) {
                    votes[0] += 1;
                } else {
                    if (x[61] <= 4.419900894165039f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            }
        } else {
            if (x[44] <= 563900.6875f) {
                if (x[0] <= 0.019399999640882015f) {
                    votes[1] += 1;
                } else {
                    votes[1] += 1;
                }
            } else {
                votes[0] += 1;
            }
        }
    } else {
        if (x[27] <= 0.02128883171826601f) {
            if (x[68] <= 84.73999786376953f) {
                if (x[41] <= -20.960000038146973f) {
                    if (x[19] <= 0.012193512637168169f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                } else {
                    if (x[0] <= -0.002800000016577542f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            } else {
                votes[0] += 1;
            }
        } else {
            if (x[83] <= 614.0950012207031f) {
                votes[1] += 1;
            } else {
                votes[1] += 1;
            }
        }
    }

    /* tree #8 */
    if (x[0] <= 0.005699999863281846f) {
        if (x[15] <= 0.004999999888241291f) {
            votes[1] += 1;
        } else {
            if (x[32] <= 0.11930212005972862f) {
                votes[0] += 1;
            } else {
                votes[0] += 1;
            }
        }
    } else {
        if (x[57] <= 148475.9140625f) {
            if (x[1] <= 0.0199491148814559f) {
                if (x[29] <= -0.07499999925494194f) {
                    if (x[30] <= 0.044999999925494194f) {
                        votes[0] += 1;
                    } else {
                        if (x[71] <= 23.888562202453613f) {
                            if (x[39] <= 16.7878999710083f) {
                                votes[0] += 1;
                            } else {
                                votes[0] += 1;
                            }
                        } else {
                            votes[0] += 1;
                        }
                    }
                } else {
                    if (x[26] <= -0.1136000007390976f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            } else {
                votes[0] += 1;
            }
        } else {
            votes[1] += 1;
        }
    }

    /* tree #9 */
    if (x[56] <= 70.57500076293945f) {
        if (x[42] <= 86.55499649047852f) {
            if (x[70] <= 147731.421875f) {
                if (x[47] <= 3.838877558708191f) {
                    votes[0] += 1;
                } else {
                    if (x[63] <= 6.5f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            } else {
                votes[0] += 1;
            }
        } else {
            votes[1] += 1;
        }
    } else {
        if (x[58] <= 35.88753890991211f) {
            if (x[67] <= 1.48499995470047f) {
                votes[0] += 1;
            } else {
                votes[0] += 1;
            }
        } else {
            if (x[2] <= -0.004999999888241291f) {
                votes[1] += 1;
            } else {
                if (x[10] <= 6.5f) {
                    votes[0] += 1;
                } else {
                    votes[0] += 1;
                }
            }
        }
    }

    /* tree #10 */
    if (x[58] <= 40.30674171447754f) {
        if (x[0] <= -0.00570000009611249f) {
            votes[1] += 1;
        } else {
            if (x[30] <= 0.06499999947845936f) {
                if (x[72] <= 31.40250015258789f) {
                    votes[0] += 1;
                } else {
                    if (x[49] <= 6.5f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            } else {
                if (x[65] <= 6.75789999961853f) {
                    votes[0] += 1;
                } else {
                    votes[1] += 1;
                }
            }
        }
    } else {
        if (x[2] <= -0.004999999888241291f) {
            votes[1] += 1;
        } else {
            if (x[2] <= 0.004999999888241291f) {
                votes[0] += 1;
            } else {
                votes[0] += 1;
            }
        }
    }

    /* tree #11 */
    if (x[2] <= -0.014999999664723873f) {
        if (x[79] <= 13.682210445404053f) {
            votes[0] += 1;
        } else {
            if (x[80] <= -0.8119188547134399f) {
                if (x[3] <= 0.004999999888241291f) {
                    votes[1] += 1;
                } else {
                    votes[0] += 1;
                }
            } else {
                votes[1] += 1;
            }
        }
    } else {
        if (x[70] <= 206897.140625f) {
            if (x[26] <= -0.1250000037252903f) {
                votes[1] += 1;
            } else {
                if (x[82] <= 0.7118806838989258f) {
                    if (x[41] <= -13.664999961853027f) {
                        if (x[78] <= 0.013378992676734924f) {
                            if (x[10] <= 2.5f) {
                                votes[0] += 1;
                            } else {
                                votes[0] += 1;
                            }
                        } else {
                            votes[0] += 1;
                        }
                    } else {
                        votes[0] += 1;
                    }
                } else {
                    if (x[70] <= 28312.212890625f) {
                        if (x[4] <= 0.014999999664723873f) {
                            votes[0] += 1;
                        } else {
                            votes[0] += 1;
                        }
                    } else {
                        votes[0] += 1;
                    }
                }
            }
        } else {
            votes[1] += 1;
        }
    }

    /* tree #12 */
    if (x[53] <= 23.54891300201416f) {
        if (x[0] <= -0.011200000066310167f) {
            votes[1] += 1;
        } else {
            if (x[35] <= 0.007141427835449576f) {
                votes[0] += 1;
            } else {
                if (x[77] <= 0.4643098711967468f) {
                    votes[1] += 1;
                } else {
                    if (x[35] <= 0.009255294688045979f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            }
        }
    } else {
        if (x[79] <= 18.608421325683594f) {
            if (x[77] <= 0.42799805104732513f) {
                votes[0] += 1;
            } else {
                votes[0] += 1;
            }
        } else {
            if (x[10] <= 11.5f) {
                if (x[57] <= 61215.904296875f) {
                    if (x[14] <= 0.009763309266418219f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                } else {
                    if (x[70] <= 14440.90625f) {
                        votes[1] += 1;
                    } else {
                        if (x[70] <= 20131.8720703125f) {
                            if (x[72] <= 19.765000343322754f) {
                                votes[0] += 1;
                            } else {
                                votes[1] += 1;
                            }
                        } else {
                            if (x[43] <= 392.7850036621094f) {
                                votes[1] += 1;
                            } else {
                                votes[1] += 1;
                            }
                        }
                    }
                }
            } else {
                votes[0] += 1;
            }
        }
    }

    /* tree #13 */
    if (x[73] <= 2.854897975921631f) {
        if (x[57] <= 105255.7734375f) {
            votes[0] += 1;
        } else {
            votes[1] += 1;
        }
    } else {
        if (x[57] <= 82110.1015625f) {
            if (x[27] <= 0.019113140180706978f) {
                if (x[66] <= 40.543914794921875f) {
                    if (x[1] <= 0.00485764117911458f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                } else {
                    votes[0] += 1;
                }
            } else {
                votes[0] += 1;
            }
        } else {
            if (x[13] <= 0.027999999932944775f) {
                if (x[37] <= 4.5f) {
                    votes[1] += 1;
                } else {
                    if (x[50] <= 7.5f) {
                        votes[1] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            } else {
                votes[1] += 1;
            }
        }
    }

    /* tree #14 */
    if (x[64] <= 0.37595102190971375f) {
        if (x[71] <= 20.06434440612793f) {
            if (x[36] <= 2.5f) {
                votes[1] += 1;
            } else {
                if (x[63] <= 8.5f) {
                    votes[0] += 1;
                } else {
                    votes[1] += 1;
                }
            }
        } else {
            if (x[66] <= 12.085309028625488f) {
                votes[0] += 1;
            } else {
                if (x[0] <= 0.020899999886751175f) {
                    votes[1] += 1;
                } else {
                    if (x[29] <= -0.0950000025331974f) {
                        votes[0] += 1;
                    } else {
                        votes[0] += 1;
                    }
                }
            }
        }
    } else {
        if (x[28] <= -0.16499999910593033f) {
            votes[1] += 1;
        } else {
            if (x[52] <= -44.23430156707764f) {
                votes[1] += 1;
            } else {
                if (x[58] <= 42.85095977783203f) {
                    if (x[69] <= 91.72000122070312f) {
                        if (x[78] <= 6.938893903907228e-18f) {
                            votes[0] += 1;
                        } else {
                            votes[0] += 1;
                        }
                    } else {
                        if (x[30] <= 0.04999999888241291f) {
                            votes[0] += 1;
                        } else {
                            votes[1] += 1;
                        }
                    }
                } else {
                    votes[1] += 1;
                }
            }
        }
    }

    /* tree #15 */
    if (x[59] <= 23.75749969482422f) {
        if (x[29] <= -0.07499999925494194f) {
            if (x[55] <= 96.375f) {
                if (x[2] <= -0.03499999921768904f) {
                    votes[1] += 1;
                } else {
                    if (x[41] <= -20.52500057220459f) {
                        if (x[60] <= 2.0823469161987305f) {
                            votes[0] += 1;
                        } else {
                            votes[0] += 1;
                        }
                    } else {
                        votes[0] += 1;
                    }
                }
            } else {
                votes[1] += 1;
            }
        } else {
            if (x[25] <= -992.2782897949219f) {
                votes[1] += 1;
            } else {
                if (x[62] <= 3.5f) {
                    votes[1] += 1;
                } else {
                    votes[1] += 1;
                }
            }
        }
    } else {
        if (x[0] <= 0.02070000022649765f) {
            if (x[0] <= 0.014500000048428774f) {
                votes[1] += 1;
            } else {
                if (x[25] <= -985.3409423828125f) {
                    votes[0] += 1;
                } else {
                    votes[1] += 1;
                }
            }
        } else {
            if (x[48] <= 23.134127616882324f) {
                votes[0] += 1;
            } else {
                votes[0] += 1;
            }
        }
    }

    /* return class with most votes */
    uint8_t winner = 0;
    for (uint8_t i = 1; i < 2; i++)
        if (votes[i] > votes[winner]) winner = i;
    return (int)winner;
}

/**
 * mc_label() - convert a class index to its human-readable name.
 * @param classIdx   value returned by mc_predict()
 * @return           "sitting", "walking", or "unknown"
 */
static inline const char *mc_label(int classIdx)
{
    switch (classIdx) {
        case 0: return "sitting";
        case 1: return "walking";
        default: return "unknown";
    }
}

#endif /* MODEL_H */
